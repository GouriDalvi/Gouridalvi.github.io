﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Collections.Specialized;
using System.Reflection;
using System.IO;


using Business_Entities;
using Business_LAccessLayer;

namespace HealthCare_MiniProject
{
    public partial class MedicalSocialHistory : System.Web.UI.Page
    {
        BusinessEntityMedical obj_entitymedical = new BusinessEntityMedical();
        Business_AccessLMedical obj_accessmedical = new Business_AccessLMedical();

        protected void Page_Load(object sender, EventArgs e)
        {
            
            
                List<string> keys = Request.Form.AllKeys.Where(key => key.Contains("txtDynamic")).ToList();
                int i = 1;
                foreach (string key in keys)
                {
                    this.CreateTextBox("txtDynamic" + i);
                    i++;
                }
            

            List<string> keys1 = Request.Form.AllKeys.Where(key2 => key2.Contains("txtDynamic1")).ToList();
            int j = 0;
            foreach (string key2 in keys1)
            {
                this.CreateTextBox1("txtDynamic1" + j);
                j++;
            }
            if (!IsPostBack)
            {
                SetIntitRowSurgeryDetails();
                SetIntitRowMedicationDetails();
                Bind_lbl();

                   
            }
        }
        
        //=========================================================================================================================================
        //Surgery Details
        //=========================================================================================================================================
        
            //Function TO ADD INITIAL ROW OF GRIDVIEW DYNAMICALLY
        private void SetIntitRowSurgeryDetails()
        {
            try 
            {
                DataTable dtSurgery = new DataTable();
                if (ViewState["SurgeryTable"] != null)
                {
                    dtSurgery = (DataTable)ViewState["SurgeryTable"];
                    gv_surgyhistory.DataSource = dtSurgery;
                    gv_surgyhistory.DataBind();
                    SetPreviousRowData_Surgery();
                }
                else
                {
                    DataRow dataRow=null;

                    dtSurgery.Columns.Add(new DataColumn("txt_year",typeof(string)));//FOR THE TEXTBOX VALUE
                    dtSurgery.Columns.Add(new DataColumn("txt_surgery",typeof(string)));//FOR THE TEXTBOX VALUE
                    dtSurgery.Columns.Add(new DataColumn("txt_location",typeof(string)));//FOR THE TEXTBOX VALUE

                    dataRow=dtSurgery.NewRow();
                    dataRow["txt_year"]=string.Empty;
                    dataRow["txt_surgery"]=string.Empty;
                    dataRow["txt_location"]=string.Empty;
                    dtSurgery.Rows.Add(dataRow);

                     //Store the DataTable in ViewState for future reference   
                    ViewState["SurgeryTable"] = dtSurgery;

                    //Bind The Girdview
                    gv_surgyhistory.DataSource=dtSurgery;
                    gv_surgyhistory.DataBind();
                }

                }
            catch(Exception ex)
            {
                Response.Write("Error..!Please Check..."+ex.Message.ToString());
            }
    
            }

        protected void gv_surgyhistory_RowCreated(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    DataTable dataTable = (DataTable)ViewState["SurgeryTable"];
                    LinkButton obj_linkbtn = (LinkButton)e.Row.FindControl("linkBtnRemove");
                    if (obj_linkbtn != null)
                    {
                        if (dataTable.Rows.Count > 1)
                        {
                            if (e.Row.RowIndex == dataTable.Rows.Count - 1)
                            {
                                obj_linkbtn.Visible = false;
                            }
                        }
                        else
                        {
                            obj_linkbtn.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
                
            }
        }
        //==================================================================================================
        //FUNCTION TO ADD THE NEW ROW IN THE GRIDVIEW

        private void AddNewRowGridSurgeryDetails()
        {
            try
            {
                if (ViewState["SurgeryTable"] != null)
                {
                    DataTable dtSurgeryTable = (DataTable)ViewState["SurgeryTable"];
                    DataRow dataRow = null;

                    if (dtSurgeryTable.Rows.Count > 0)
                    {
                        dataRow = dtSurgeryTable.NewRow();

                        //add the row to DataTable
                        dtSurgeryTable.Rows.Add(dataRow);

                        //store the current data to viewstate for the future reference
                        ViewState["SurgeryTable"] = dtSurgeryTable;

                        for (int i = 0; i < dtSurgeryTable.Rows.Count - 1; i++)
                        {
                            //extract the Textbox values
                            TextBox Surgery_Year = (TextBox)gv_surgyhistory.Rows[i].Cells[0].FindControl("txt_year");
                            TextBox Surgery_Name = (TextBox)gv_surgyhistory.Rows[i].Cells[1].FindControl("txt_surgery");
                            TextBox Surgery_Location = (TextBox)gv_surgyhistory.Rows[i].Cells[2].FindControl("txt_location");

                            dtSurgeryTable.Rows[0]["txt_year"] = Surgery_Year.Text;
                            dtSurgeryTable.Rows[0]["txt_surgery"] = Surgery_Name.Text;
                            dtSurgeryTable.Rows[0]["txt_location"] = Surgery_Location.Text;

                        }

                        //Rebind the grid with the current data to reflect  changes
                        gv_surgyhistory.DataSource = dtSurgeryTable;
                        gv_surgyhistory.DataBind();

                        ViewState["SurgeryTable"] = dtSurgeryTable;
                    }
                }
                else
                {
                    Response.Write("<Script>alert('Surgery Details are null')</Script>");
                }

                //Set Previous Data on Postbacks
                SetPreviousRowData_Surgery();
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
            }
        }

        //============================================================================================================================
        //FUNCTION TO SET THE PREVIOUS DATA TO GRIDVIEW ROWS
        private void SetPreviousRowData_Surgery()
        {
            try
            {
                int RowIndex = 0;
                if (ViewState["SurgeryTable"] != null)
                {
                    DataTable dataTable = (DataTable)ViewState["SurgeryTable"];
                    if (dataTable.Rows.Count > 0)
                    {
                        for (int i = 0; i <= dataTable.Rows.Count - 1; i++)
                        {
                            TextBox Surgery_Year = (TextBox)gv_surgyhistory.Rows[i].Cells[0].FindControl("txt_year");
                            TextBox Surgery_Name = (TextBox)gv_surgyhistory.Rows[i].Cells[1].FindControl("txt_surgery");
                            TextBox Surgery_Location = (TextBox)gv_surgyhistory.Rows[i].Cells[2].FindControl("txt_location");

                            //Assign the value from DataTable to TextBox

                            Surgery_Year.Text = dataTable.Rows[i]["txt_year"].ToString();
                            Surgery_Name.Text = dataTable.Rows[i]["txt_surgery"].ToString();
                            Surgery_Location.Text = dataTable.Rows[i]["txt_location"].ToString();

                            RowIndex++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
            }
        }
        //=====================================================================================================

        protected void btnAddNewRoomType_Click(object sender, EventArgs e)
        {
            try
            {
                AddNewRowGridSurgeryDetails();
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>");
            }
        }

        protected void linkBtnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                LinkButton btnLinkRemove = (LinkButton)sender;
                GridViewRow gvRow = (GridViewRow)btnLinkRemove.NamingContainer;

                int rowID = gvRow.RowIndex;
                if (ViewState["SurgeryTable"] != null)
                {
                    DataTable dataTable = (DataTable)ViewState["SurgeryTable"];
                    if (dataTable.Rows.Count > 1)
                    {
                        if (gvRow.RowIndex < dataTable.Rows.Count - 1)
                        {
                            //Remove the selected Row from the gridview
                            dataTable.Rows.Remove(dataTable.Rows[rowID]);
                        }
                    }

                    //Store the current data in viewstate for future state
                    ViewState["SurgeryTable"] = dataTable;

                    //Rebind the Gridview for the updated data
                    gv_surgyhistory.DataSource = dataTable;
                    gv_surgyhistory.DataBind();

                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
            }
        }

//=========================================================================================================================================
        //Medication Details
//=========================================================================================================================================
        //Function TO ADD INITIAL ROW OF GRIDVIEW DYNAMICALLY
        private void SetIntitRowMedicationDetails()
        {
            try
            {
                DataTable dtmedication = new DataTable();
                if (ViewState["MedicationTable"] != null)
                {
                    dtmedication = (DataTable)ViewState["MedicationTable"];
                    gv_medication.DataSource = dtmedication;
                    gv_medication.DataBind();
                    SetPreviousRowData_Medication();
                }
                else
                {
                    DataRow dataRow = null;

                    dtmedication.Columns.Add(new DataColumn("txt_medication", typeof(string)));//FOR THE TEXTBOX VALUE
                    dtmedication.Columns.Add(new DataColumn("txt_strength", typeof(string)));//FOR THE TEXTBOX VALUE
                    dtmedication.Columns.Add(new DataColumn("txt_doseform", typeof(string)));//FOR THE TEXTBOX VALUE

                    dataRow = dtmedication.NewRow();
                    dataRow["txt_medication"] = string.Empty;
                    dataRow["txt_strength"] = string.Empty;
                    dataRow["txt_doseform"] = string.Empty;
                    dtmedication.Rows.Add(dataRow);

                    //Store the DataTable in ViewState for future reference   
                    ViewState["MedicationTable"] = dtmedication;

                    //Bind The Girdview
                    gv_medication.DataSource = dtmedication;
                    gv_medication.DataBind();
                }

            }
            catch (Exception ex)
            {
                Response.Write("Error..!Please Check..." + ex.Message.ToString());
            }

        }

        //==================================================================================================
        //FUNCTION TO ADD THE NEW ROW IN THE GRIDVIEW

        private void AddNewRowGridMedicationDetails()
        {
            try
            {
                if (ViewState["MedicationTable"] != null)
                {
                    DataTable dtMedicationTable = (DataTable)ViewState["MedicationTable"];
                    DataRow dataRow = null;

                    if (dtMedicationTable.Rows.Count > 0)
                    {
                        dataRow = dtMedicationTable.NewRow();

                        //add the row to DataTable
                        dtMedicationTable.Rows.Add(dataRow);

                        //store the current data to viewstate for the future reference
                        ViewState["MedicationTable"] = dtMedicationTable;

                        for (int i = 0; i < dtMedicationTable.Rows.Count - 1; i++)
                        {
                            //extract the Textbox values
                            TextBox Medication = (TextBox)gv_medication.Rows[i].Cells[0].FindControl("txt_medication");
                            TextBox strength = (TextBox)gv_medication.Rows[i].Cells[1].FindControl("txt_strength");
                            TextBox doseform = (TextBox)gv_medication.Rows[i].Cells[2].FindControl("txt_doseform");

                            dtMedicationTable.Rows[0]["txt_medication"] = Medication.Text;
                            dtMedicationTable.Rows[0]["txt_strength"] = strength.Text;
                            dtMedicationTable.Rows[0]["txt_doseform"] = doseform.Text;

                        }

                        //Rebind the grid with the current data to reflect  changes
                        gv_medication.DataSource = dtMedicationTable;
                        gv_medication.DataBind();

                        ViewState["MedicationTable"] = dtMedicationTable;
                    }
                }
                else
                {
                    Response.Write("<Script>alert('Surgery Details are null')</Script>");
                }

                //Set Previous Data on Postbacks
                SetPreviousRowData_Medication();
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
            }
        }

        //============================================================================================================================
        //FUNCTION TO SET THE PREVIOUS DATA TO GRIDVIEW ROWS
        private void SetPreviousRowData_Medication()
        {
            try
            {
                int RowIndex = 0;
                if (ViewState["MedicationTable"] != null)
                {
                    DataTable dataTable = (DataTable)ViewState["MedicationTable"];
                    if (dataTable.Rows.Count > 0)
                    {
                        for (int i = 0; i <= dataTable.Rows.Count - 1; i++)
                        {
                            TextBox Medication = (TextBox)gv_medication.Rows[i].Cells[0].FindControl("txt_medication");
                            TextBox strength = (TextBox)gv_medication.Rows[i].Cells[1].FindControl("txt_strength");
                            TextBox doseform = (TextBox)gv_medication.Rows[i].Cells[2].FindControl("txt_doseform");

                            //Assign the value from DataTable to TextBox

                            Medication.Text = dataTable.Rows[i]["txt_medication"].ToString();
                            strength.Text = dataTable.Rows[i]["txt_strength"].ToString();
                            doseform.Text = dataTable.Rows[i]["txt_doseform"].ToString();

                            RowIndex++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
            }
        }


//=====================================================================================================================

        protected void btnAddNewMedication_Click(object sender, EventArgs e)
        {
            try
            {
                AddNewRowGridMedicationDetails();
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>");
            }
        }

        protected void linkBtnRemoveM_Click(object sender, EventArgs e)
        {
            try
            {
                LinkButton btnLinkRemoveM = (LinkButton)sender;
                GridViewRow gvRow = (GridViewRow)btnLinkRemoveM.NamingContainer;

                int rowID = gvRow.RowIndex;
                if (ViewState["MedicationTable"] != null)
                {
                    DataTable dataTable = (DataTable)ViewState["MedicationTable"];
                    if (dataTable.Rows.Count > 1)
                    {
                        if (gvRow.RowIndex < dataTable.Rows.Count - 1)
                        {
                            //Remove the selected Row from the gridview
                            dataTable.Rows.Remove(dataTable.Rows[rowID]);
                        }
                    }

                    //Store the current data in viewstate for future state
                    ViewState["MedicationTable"] = dataTable;

                    //Rebind the Gridview for the updated data
                    gv_medication.DataSource = dataTable;
                    gv_medication.DataBind();

                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
            }
        }

        protected void gv_medication_RowCreated(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    DataTable dataTable = (DataTable)ViewState["MedicationTable"];
                    LinkButton obj_linkbtn = (LinkButton)e.Row.FindControl("linkBtnRemoveM");
                    if (obj_linkbtn != null)
                    {
                        if (dataTable.Rows.Count > 1)
                        {
                            if (e.Row.RowIndex == dataTable.Rows.Count - 1)
                            {
                                obj_linkbtn.Visible = false;
                            }
                        }
                        else
                        {
                            obj_linkbtn.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());

            }
        }

        private List<SurgeryMedication> GetSurgeryMedicationList()
        {
            int RowIndex=0;
            List<SurgeryMedication> obj_surgerydtl = new List<SurgeryMedication>();
            try
            {
                if (ViewState["SurgeryTable"] != null)
                {
                    DataTable dtsurgermedica = (DataTable)ViewState["SurgeryTable"];
                    if (dtsurgermedica.Rows.Count > 0)
                    {
                        for (int i = 1; i < dtsurgermedica.Rows.Count; i++)
                        {
                            TextBox Surgery_Year1 = (TextBox)gv_surgyhistory.Rows[RowIndex].Cells[0].FindControl("txt_year");
                            TextBox Surgery_Name1 = (TextBox)gv_surgyhistory.Rows[RowIndex].Cells[1].FindControl("txt_surgery");
                            TextBox Surgery_Location1 = (TextBox)gv_surgyhistory.Rows[RowIndex].Cells[2].FindControl("txt_location");
                            

                            SurgeryMedication objSM = new SurgeryMedication();
                            objSM.Surgery_Year = Surgery_Year1.Text;
                            objSM.Surgery_Name = Surgery_Name1.Text;
                            objSM.Surgery_Location = Surgery_Location1.Text;
                            
                            objSM.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                            obj_surgerydtl.Add(objSM);
                            RowIndex++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());

            }
            return obj_surgerydtl;
        }
        private List<Medication1> GetMedicationList()
        {
            int RowIndex = 0;
            List<Medication1> obj_surgerydtl1 = new List<Medication1>();
            try
            {
                if (ViewState["MedicationTable"] != null)
                {
                    DataTable dtmedica2 = (DataTable)ViewState["MedicationTable"];
                    if (dtmedica2.Rows.Count > 0)
                    {
                        for (int i = 1; i < dtmedica2.Rows.Count; i++)
                        {
                            
                            TextBox Medication1 = (TextBox)gv_medication.Rows[RowIndex].Cells[0].FindControl("txt_medication");
                            TextBox strength1 = (TextBox)gv_medication.Rows[RowIndex].Cells[1].FindControl("txt_strength");
                            TextBox doseform1 = (TextBox)gv_medication.Rows[RowIndex].Cells[2].FindControl("txt_doseform");

                            Medication1 objSM1 = new Medication1();
                            
                            objSM1.Medication = Medication1.Text;
                            objSM1.strength = strength1.Text;
                            objSM1.doseform = doseform1.Text;
                            objSM1.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                            obj_surgerydtl1.Add(objSM1);
                            RowIndex++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());

            }
            return obj_surgerydtl1;
        }

       

        public void Bind_lbl()
        {
            Business_AccessLayer obj_Acceslayer = new Business_AccessLayer();
            Business_Entity obj_entity = new Business_Entity();
            string Name;
            try
            {
                Name = Session["Login"].ToString();

                obj_entity = obj_Acceslayer.Get_bind_patient(Name);

                lbl_patient_id.Text = obj_entity.Patient_Id.ToString();

            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());
                
            }
        }


        protected void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string medical_listitem = string.Empty;
                foreach (ListItem item in chk_med_history.Items)
                {
                    if (item.Selected)
                        medical_listitem += item + ",";
                }

                string smokedetector = string.Empty;
                if (btnrd_yes.Checked)
                {
                    smokedetector = "Yes";
                }
                else if (btnrd_no.Checked)
                {
                    smokedetector = "No";
                }

                string smokexposure = string.Empty;
                if (btnrd_smkexpyes.Checked)
                {
                    smokexposure = "Yes";
                }
                else if (btn_smkexpno.Checked)
                {
                    smokexposure = "No";
                }

                string co = string.Empty;
                if (btnrd_coyes.Checked)
                {
                    co = "Yes";
                }
                else if (btnrd_cono.Checked)
                {
                    co = "No";
                }

                string firearm = string.Empty;
                if (btnrd_fireyes.Checked && RadioButton1.Checked)
                {
                    firearm = "Yes";
                    firearm = "Yes";
                }
                else if (btnrd_cono.Checked && RadioButton2.Checked)
                {
                    firearm = "No";
                    firearm = "No";
                }

                string message = "";

                foreach (TextBox textBox in pnlTextBoxes.Controls.OfType<TextBox>())
                {
                    message += textBox.Text;
                }

                string message1 = "";

                foreach (TextBox textBox1 in Panel1.Controls.OfType<TextBox>())
                {
                    message1 += textBox1.Text;
                }

                obj_entitymedical.Medical_History = medical_listitem.ToString();
                obj_entitymedical.Other_Medical_Cond = txt_othercondn.Text;
                obj_entitymedical.Parent_Marital_Status = ddl_parentstatus.SelectedValue.ToString();
                obj_entitymedical.Allergy = message;
                obj_entitymedical.Pharmacy = message1;
                obj_entitymedical.Lives_with = ddl_liveswith.SelectedValue.ToString();
                obj_entitymedical.Occupation = txt_occupation.Text;
                obj_entitymedical.Pets = ddl_pets.SelectedValue.ToString();
                obj_entitymedical.Smoke_Detector = smokedetector;
                obj_entitymedical.Smoking_Status = ddl_smokingstatus.SelectedValue.ToString();
                obj_entitymedical.Comment = txt_comments.Text;
                obj_entitymedical.Start_Smoking_Date = txt_startsmkdate.Text;
                obj_entitymedical.Quit_Smoking_Date = txt_quitsmkdate.Text;
                obj_entitymedical.Smoke_Exposure = smokexposure;
                obj_entitymedical.CO_Detector = co;
                obj_entitymedical.Firearms = firearm;
                obj_entitymedical.Type_Day_Care = ddl_typecare.SelectedValue.ToString();
                obj_entitymedical.Day_Care_days_per_week = ddl_daycareweek.SelectedValue.ToString();
                obj_entitymedical.Current_school_level = ddl_schoollvl.SelectedValue.ToString();
                obj_entitymedical.Average_Grades = ddl_avggrd.SelectedValue.ToString();
                obj_entitymedical.Activities = txt_activties.Text;
                obj_entitymedical.Bike_Helmet_usage = ddl_bikehelmetuse.SelectedValue.ToString();
                obj_entitymedical.Seat_Helmet_usage = ddl_seatbeltuse.SelectedValue.ToString();
                obj_entitymedical.Car_Helmet_usage = ddl_carseatuse.SelectedValue.ToString();
                obj_entitymedical.Average_diet = ddl_avgdiet.SelectedValue.ToString();
                obj_entitymedical.Milk_usage = ddl_milkuse.SelectedValue.ToString();
                obj_entitymedical.No_of_oz_per_day = txt_no_of_ozday.Text;
                obj_entitymedical.Water_usage = ddl_wateruse.SelectedValue.ToString();
                obj_entitymedical.Sleeping_location = ddl_sleeploc.SelectedValue.ToString();
                obj_entitymedical.Sleeping_frequency = ddl_sleepfrqcy.SelectedValue.ToString();
                obj_entitymedical.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                List<SurgeryMedication> SurgeryList = GetSurgeryMedicationList();
                List<Medication1> MedicationList = GetMedicationList();
               
                obj_accessmedical.Get_Medical_History_Dtl(obj_entitymedical, SurgeryList,MedicationList);

                Response.Write("<Script>alert('Details are Save Successfully...')</Script>");

            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());

            }
        }
        //======================================================================================================================
        //Selecting data to update
        //======================================================================================================================        
        protected void btn_Update_Click(object sender, EventArgs e)
        {
            BusinessEntityMedical obj_entitymedical1 = new BusinessEntityMedical();
            try
            {
                string medical_listitem = string.Empty;
                foreach (ListItem item in chk_med_history.Items)
                {
                    if (item.Selected)
                        medical_listitem += item + ",";
                }
                string smokedetector = string.Empty;
                if (btnrd_yes.Checked)
                {
                    smokedetector = "Yes";
                }
                else if (btnrd_no.Checked)
                {
                    smokedetector = "No";
                }

                string smokexposure = string.Empty;
                if (btnrd_smkexpyes.Checked)
                {
                    smokexposure = "Yes";
                }
                else if (btn_smkexpno.Checked)
                {
                    smokexposure = "No";
                }

                string co = string.Empty;
                if (btnrd_coyes.Checked)
                {
                    co = "Yes";
                }
                else if (btnrd_cono.Checked)
                {
                    co = "No";
                }

                string firearm = string.Empty;
                if (btnrd_fireyes.Checked && RadioButton1.Checked)
                {
                    firearm = "Yes";
                    firearm = "Yes";
                }
                else if (btnrd_cono.Checked && RadioButton2.Checked)
                {
                    firearm = "No";
                    firearm = "No";
                }

                string message = "";

                foreach (TextBox textBox in pnlTextBoxes.Controls.OfType<TextBox>())
                {
                    message += textBox.Text;
                }

                string message1 = "";

                foreach (TextBox textBox1 in Panel1.Controls.OfType<TextBox>())
                {
                    message1 += textBox1.Text;
                }

                obj_entitymedical1.Medical_History = medical_listitem.ToString();
                obj_entitymedical1.Other_Medical_Cond = txt_othercondn.Text;
                obj_entitymedical1.Parent_Marital_Status = ddl_parentstatus.SelectedValue.ToString();
                obj_entitymedical1.Allergy = message;
                obj_entitymedical1.Pharmacy = message1;
                obj_entitymedical1.Lives_with = ddl_liveswith.SelectedValue.ToString();
                obj_entitymedical1.Occupation = txt_occupation.Text;
                obj_entitymedical1.Pets = ddl_pets.SelectedValue.ToString();
                obj_entitymedical1.Smoke_Detector = smokedetector;
                obj_entitymedical1.Smoking_Status = ddl_smokingstatus.SelectedValue.ToString();
                obj_entitymedical1.Comment = txt_comments.Text;
                obj_entitymedical1.Start_Smoking_Date = txt_startsmkdate.Text;
                obj_entitymedical1.Quit_Smoking_Date = txt_quitsmkdate.Text;
                obj_entitymedical1.Smoke_Exposure = smokexposure;
                obj_entitymedical1.CO_Detector = co;
                obj_entitymedical1.Firearms = firearm;
                obj_entitymedical1.Type_Day_Care = ddl_typecare.SelectedValue.ToString();
                obj_entitymedical1.Day_Care_days_per_week = ddl_daycareweek.SelectedValue.ToString();
                obj_entitymedical1.Current_school_level = ddl_schoollvl.SelectedValue.ToString();
                obj_entitymedical1.Average_Grades = ddl_avggrd.SelectedValue.ToString();
                obj_entitymedical1.Activities = txt_activties.Text;
                obj_entitymedical1.Bike_Helmet_usage = ddl_bikehelmetuse.SelectedValue.ToString();
                obj_entitymedical1.Seat_Helmet_usage = ddl_seatbeltuse.SelectedValue.ToString();
                obj_entitymedical1.Car_Helmet_usage = ddl_carseatuse.SelectedValue.ToString();
                obj_entitymedical1.Average_diet = ddl_avgdiet.SelectedValue.ToString();
                obj_entitymedical1.Milk_usage = ddl_milkuse.SelectedValue.ToString();
                obj_entitymedical1.No_of_oz_per_day = txt_no_of_ozday.Text;
                obj_entitymedical1.Water_usage = ddl_wateruse.SelectedValue.ToString();
                obj_entitymedical1.Sleeping_location = ddl_sleeploc.SelectedValue.ToString();
                obj_entitymedical1.Sleeping_frequency = ddl_sleepfrqcy.SelectedValue.ToString();
                obj_entitymedical1.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                obj_accessmedical.Get_SUpdate_Medical_History(obj_entitymedical1);
                Response.Write("<Script>alert('Details are Updated Successfully...')</Script>");

                

            }
            catch(Exception ex) 
            {
                Response.Write("<Script>alert('Oops..!Error Occure')</Script>" + ex.Message.ToString());

            }

        }

        

        private void CreateTextBox(string id)
        {
            TextBox txt = new TextBox();
            txt.ID = id;
            pnlTextBoxes.Controls.Add(txt);

            Literal lt = new Literal();
            lt.Text = "<br />";
            pnlTextBoxes.Controls.Add(lt);
        }
        private void CreateTextBox1(string id)
        {
            TextBox txt = new TextBox();
            txt.ID = id;
            Panel1.Controls.Add(txt);

            Literal lt = new Literal();
            lt.Text = "<br />";
            Panel1.Controls.Add(lt);
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            int index = pnlTextBoxes.Controls.OfType<TextBox>().ToList().Count + 1;
        this.CreateTextBox("txtDynamic" + index);
        }

        protected void btn_addp_Click(object sender, EventArgs e)
        {
            int index = Panel1.Controls.OfType<TextBox>().ToList().Count + 1;
            this.CreateTextBox1("txtDynamic1" + index);
        }

        


        }//class
    }//Namespace
