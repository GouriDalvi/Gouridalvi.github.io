﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HealthCare_MiniProject
{
    public partial class Main_Master : System.Web.UI.MasterPage
    {
        SqlConnection Sql_Con = new SqlConnection(ConfigurationManager.ConnectionStrings["HealthCare_ConStr"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            lbl_date.Text = System.DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss");

            string query = "Select * from tbl_Patient where Patient_FName='" + Session["Login"] + "'";
            SqlCommand cmd = new SqlCommand(query, Sql_Con);
            Sql_Con.Open();
            SqlDataReader obj_reader = cmd.ExecuteReader();
            while (obj_reader.Read())
            {
                lbl_Dob.Text = obj_reader["Patient_DOB"].ToString();
                lbl_age.Text = obj_reader["Patient_Age"].ToString();
            }
            Sql_Con.Close();
        }
    }
}