﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Business_Entities;
using Business_LAccessLayer;

namespace HealthCare_MiniProject
{
    public partial class Demographics : System.Web.UI.Page
    {
        Business_AccessLayer obj_Acceslayer = new Business_AccessLayer();
        Business_Entity obj_entity = new Business_Entity();
        Demograph obj_demo_main = new Demograph();
        Demograph_Bill obj_demo_bill = new Demograph_Bill();
        Demograph_Emp obj_demo_emp = new Demograph_Emp();
        Demograph_Emg_Cnt1 obj_demo_emgr1 = new Demograph_Emg_Cnt1();
        Demograph_Emg_Cnt2 obj_demo_emgr2 = new Demograph_Emg_Cnt2();
        Demograph_Emg_Cnt3 obj_demo_emgr3 = new Demograph_Emg_Cnt3();

        protected void Page_Load(object sender, EventArgs e)
        {
            ((Panel)Master.FindControl("panel1")).Visible = true;

            if (Session["Login"] == null)
            {
                Response.Redirect("Login_Form.aspx");
            }

            if (!IsPostBack)
            {
                Bind_lbl();
            }

            
        }

        public void Bind_lbl()
        {
            string Name;
            try
            {
                Name = Session["Login"].ToString();

                obj_entity = obj_Acceslayer.Get_bind_patient(Name);

                lbl_patient_id.Text = obj_entity.Patient_Id.ToString();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                //main data
                obj_demo_main.P_Gender = ddl_Gender.SelectedValue.ToString();
                obj_demo_main.Race = chk_race.SelectedValue.ToString();
                obj_demo_main.Ethnicity = ddl_Ethnicity.SelectedValue.ToString();
                obj_demo_main.Language = ddl_lang.SelectedValue.ToString();
                obj_demo_main.HomePhone = txt_homephone.Text;
                obj_demo_main.CellPhone = txt_cellphone.Text;
                obj_demo_main.WorkPhone = txt_workphone.Text;
                obj_demo_main.EmailAddress = txt_emailaddr.Text;
                obj_demo_main.DirectAddress = txt_directaddr.Text;
                obj_demo_main.Phy_Addr1 = txt_phyaddress1.Text;
                obj_demo_main.Phy_Addr2 = txt_phyaddress2.Text;
                obj_demo_main.Phy_ACity = txt_phycity.Text;
                obj_demo_main.Phy_AState = txt_phystate.Text;
                obj_demo_main.Phy_AZipcode = txt_phyzipcode.Text;
                obj_demo_main.Insurance = lbl_insurance.Text;
                obj_demo_main.HearAboutus = ddl_aboutus.SelectedValue.ToString();
                obj_demo_main.Provider = ddl_provider.SelectedValue.ToString();
                obj_demo_main.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                    //billing data
                    obj_demo_bill.Bill_Addr1 = txt_billaddr1.Text;
                    obj_demo_bill.Bill_Addr2 = txt_billaddr2.Text;
                    obj_demo_bill.Bill_City = txt_billcity.Text;
                    obj_demo_bill.Bill_State = txt_billstate.Text;
                    obj_demo_bill.Bill_Zipcode = txt_billzipcode.Text;
                    obj_demo_bill.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                     //employee data
                    obj_demo_emp.Emp_Name = txt_empname.Text;
                    obj_demo_emp.Emp_Addr1 = txt_empaddr1.Text;
                    obj_demo_emp.Emp_Addr2 = txt_empaddr2.Text;
                    obj_demo_emp.Emp_City = txt_empcity.Text;
                    obj_demo_emp.Emp_State = txt_empstate.Text;
                    obj_demo_emp.Emp_Zipcode = txt_empzipcode.Text;
                    obj_demo_emp.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                
                    //emergency contact1
                    obj_demo_emgr1.Emrcnt1_Name = txt_emgcntname.Text;
                    obj_demo_emgr1.Emrcnt1_Addr1 = txt_emgcntaddr1.Text;
                    obj_demo_emgr1.Emrcnt1_Addr2 = txt_emgcntaddr2.Text;
                    obj_demo_emgr1.Emrcnt1_City = txt_emgcntcity.Text;
                    obj_demo_emgr1.Emrcnt1_State = txt_emgcntstate.Text;
                    obj_demo_emgr1.Emrcnt1_Zipcode = txt_emgcntzipcode.Text;
                    obj_demo_emgr1.Emrcnt1_Homeph = txt_emghomeph.Text;
                    obj_demo_emgr1.Emrcnt1_Cellph = txt_emgcellph.Text;
                    obj_demo_emgr1.Emrcnt1_Workph = txt_emgworkph.Text;
                    obj_demo_emgr1.Emrcnt1_Relpatient = ddl_emg1rel_patient.SelectedValue.ToString();
                    obj_demo_emgr1.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                    //emergency contact2
                    obj_demo_emgr2.Emrcnt2_Name = txt_emgcnt2name.Text;
                    obj_demo_emgr2.Emrcnt2_Addr1 = txt_emgcnt2addr1.Text;
                    obj_demo_emgr2.Emrcnt2_Addr2 = txt_emgcnt2addr2.Text;
                    obj_demo_emgr2.Emrcnt2_City = txt_emgcnt2city.Text;
                    obj_demo_emgr2.Emrcnt2_State = txt_emgcnt2state.Text;
                    obj_demo_emgr2.Emrcnt2_Zipcode = txt_emgcnt2zipcode.Text;
                    obj_demo_emgr2.Emrcnt2_Homeph = txt_emgcnt2homeph.Text;
                    obj_demo_emgr2.Emrcnt2_Cellph = txt_emgcnt2cellph.Text;
                    obj_demo_emgr2.Emrcnt2_Workph = txt_emgcnt2workph.Text;
                    obj_demo_emgr2.Emrcnt2_Relpatient = ddl_emg2rel_patient.SelectedValue.ToString();
                    obj_demo_emgr2.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                    //emergency contact3
                    obj_demo_emgr3.Emrcnt3_Name = txt_emg3name.Text;
                    obj_demo_emgr3.Emrcnt3_Addr1 = txt_emg3addr1.Text;
                    obj_demo_emgr3.Emrcnt3_Addr2 = txt_emg3addr2.Text;
                    obj_demo_emgr3.Emrcnt3_City = txt_emg3city.Text;
                    obj_demo_emgr3.Emrcnt3_State = txt_emg3state.Text;
                    obj_demo_emgr3.Emrcnt3_Zipcode = txt_emg3zipcode.Text;
                    obj_demo_emgr3.Emrcnt3_Homeph = txt_emg3homeph.Text;
                    obj_demo_emgr3.Emrcnt3_Cellph = txt_emg3cellph.Text;
                    obj_demo_emgr3.Emrcnt3_Workph = txt_emg3workph.Text;
                    obj_demo_emgr3.Emrcnt3_Relpatient = ddl_emg3re_patient.SelectedValue.ToString();
                    obj_demo_emgr3.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                    //All fuction to add details to tables

                    obj_Acceslayer.Get_Demo_Main(obj_demo_main);
                    obj_Acceslayer.Get_Demo_Bill(obj_demo_bill);
                    obj_Acceslayer.Get_Demo_Emp(obj_demo_emp);
                    obj_Acceslayer.Get_Demo_Emerg1(obj_demo_emgr1);
                    obj_Acceslayer.Get_Demo_Emerg2(obj_demo_emgr2);
                    obj_Acceslayer.Get_Demo_Emerg3(obj_demo_emgr3);

                    Response.Write("<Script>alert('Details are Save Successfully...')</Script>");
                    cleartextbox();

            }
            catch (Exception ex)
            {
                Response.Write("Oops!Error Occure...Please Check..." + ex.Message.ToString());
            }

        }

        protected void chk_billaddr_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_billaddr.Checked)
            {
                txt_billaddr1.Text = txt_phyaddress1.Text;
                txt_billaddr2.Text = txt_phyaddress2.Text;
                txt_billcity.Text = txt_phycity.Text;
                txt_billstate.Text = txt_phystate.Text;
                txt_billzipcode.Text = txt_phyzipcode.Text;
            }
        }

        protected void chk_emgcont1_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_emgcont1.Checked)
            {
                txt_emgcntaddr1.Text = txt_phyaddress1.Text;
                txt_emgcntaddr2.Text = txt_phyaddress2.Text;
                txt_emgcntcity.Text = txt_phycity.Text;
                txt_emgcntstate.Text = txt_phystate.Text;
                txt_emgcntzipcode.Text = txt_phyzipcode.Text;
                txt_emghomeph.Text = txt_homephone.Text;
                txt_emgcellph.Text = txt_cellphone.Text;
                txt_emgworkph.Text = txt_workphone.Text;
            }
        }

        protected void chk_emgcont2_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_emgcont2.Checked)
            {
                txt_emgcnt2addr1.Text = txt_phyaddress1.Text;
                txt_emgcnt2addr2.Text = txt_phyaddress2.Text;
                txt_emgcnt2city.Text = txt_phycity.Text;
                txt_emgcnt2state.Text = txt_phystate.Text;
                txt_emgcnt2zipcode.Text = txt_phyzipcode.Text;
                txt_emgcnt2homeph.Text = txt_homephone.Text;
                txt_emgcnt2cellph.Text = txt_cellphone.Text;
                txt_emgcnt2workph.Text = txt_workphone.Text;
            }
        }

        protected void chk_emg3_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_emg3.Checked)
            {
                txt_emg3addr1.Text = txt_phyaddress1.Text;
                txt_emg3addr2.Text = txt_phyaddress2.Text;
                txt_emg3city.Text = txt_phycity.Text;
                txt_emg3state.Text = txt_phystate.Text;
                txt_emg3zipcode.Text = txt_phyzipcode.Text;
                txt_emg3homeph.Text = txt_homephone.Text;
                txt_emg3cellph.Text = txt_cellphone.Text;
                txt_emg3workph.Text = txt_workphone.Text;
            }
        }
//======================================================================================================================
        //Selecting data to update
//======================================================================================================================        

        protected void btn_Update_Click(object sender, EventArgs e)
        {
            btn_Update1.Visible = true;
            //string name;
            int id;
            try 
            {
                //name = Session["Login"].ToString();
                id = Convert.ToInt32(lbl_patient_id.Text);
                obj_demo_main = obj_Acceslayer.Get_SUpdate_Details(id);
                obj_demo_bill = obj_Acceslayer.Get_SUpdateBill_Details(id);
                obj_demo_emp = obj_Acceslayer.Get_SUpdateEmp_Details(id);
                obj_demo_emgr1 = obj_Acceslayer.Get_SUpdateEmr1_Details(id);
                obj_demo_emgr2 = obj_Acceslayer.Get_SUpdateEmr2_Details(id);
                obj_demo_emgr3 = obj_Acceslayer.Get_SUpdateEmr3_Details(id);


                //main data
                 //ddl_Gender.SelectedValue.ToString();
                 //chk_race.SelectedValue.ToString();
                // ddl_Ethnicity.SelectedValue.ToString();
                //ddl_lang.SelectedValue.ToString();
                 txt_homephone.Text=obj_demo_main.HomePhone.ToString();
                 txt_cellphone.Text=obj_demo_main.CellPhone.ToString();
                 txt_workphone.Text=obj_demo_main.WorkPhone.ToString();
                 txt_emailaddr.Text=obj_demo_main.EmailAddress.ToString();
                 txt_directaddr.Text=obj_demo_main.DirectAddress.ToString();
                 txt_phyaddress1.Text=obj_demo_main.Phy_Addr1.ToString();
                 txt_phyaddress2.Text=obj_demo_main.Phy_Addr2.ToString();
                 txt_phycity.Text=obj_demo_main.Phy_ACity.ToString();
                 txt_phystate.Text=obj_demo_main.Phy_AState.ToString();
                 txt_phyzipcode.Text=obj_demo_main.Phy_AZipcode.ToString();
                 lbl_insurance.Text=obj_demo_main.Insurance.ToString();
                 //ddl_aboutus.SelectedValue.ToString();
                 //ddl_provider.SelectedValue.ToString();
                //obj_demo_main.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                //billing data
                txt_billaddr1.Text=obj_demo_bill.Bill_Addr1.ToString();
                txt_billaddr2.Text = obj_demo_bill.Bill_Addr2.ToString();
                txt_billcity.Text = obj_demo_bill.Bill_City.ToString();
                txt_billstate.Text = obj_demo_bill.Bill_State.ToString();
                txt_billzipcode.Text = obj_demo_bill.Bill_Zipcode.ToString();
                //obj_demo_bill.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //employee data
                txt_empname.Text = obj_demo_emp.Emp_Name.ToString();
                txt_empaddr1.Text = obj_demo_emp.Emp_Addr1.ToString();
                txt_empaddr2.Text = obj_demo_emp.Emp_Addr2.ToString();
                txt_empcity.Text = obj_demo_emp.Emp_City.ToString();
                txt_empstate.Text = obj_demo_emp.Emp_State.ToString();
                txt_empzipcode.Text = obj_demo_emp.Emp_Zipcode.ToString();
                //obj_demo_emp.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //emergency contact1
                txt_emgcntname.Text = obj_demo_emgr1.Emrcnt1_Name.ToString();
                txt_emgcntaddr1.Text = obj_demo_emgr1.Emrcnt1_Addr1.ToString();
                txt_emgcntaddr2.Text = obj_demo_emgr1.Emrcnt1_Addr2.ToString();
                txt_emgcntcity.Text = obj_demo_emgr1.Emrcnt1_City.ToString();
                txt_emgcntstate.Text = obj_demo_emgr1.Emrcnt1_State.ToString();
                txt_emgcntzipcode.Text = obj_demo_emgr1.Emrcnt1_Zipcode.ToString();
                txt_emghomeph.Text = obj_demo_emgr1.Emrcnt1_Homeph.ToString();
                txt_emgcellph.Text = obj_demo_emgr1.Emrcnt1_Cellph.ToString();
                txt_emgworkph.Text = obj_demo_emgr1.Emrcnt1_Workph.ToString();
                //obj_demo_emgr1.Emrcnt1_Relpatient = ddl_emg1rel_patient.SelectedValue.ToString();
                //obj_demo_emgr1.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //emergency contact2
                txt_emgcnt2name.Text = obj_demo_emgr2.Emrcnt2_Name.ToString();
                txt_emgcnt2addr1.Text = obj_demo_emgr2.Emrcnt2_Addr1.ToString();
                txt_emgcnt2addr2.Text = obj_demo_emgr2.Emrcnt2_Addr2.ToString();
                txt_emgcnt2city.Text = obj_demo_emgr2.Emrcnt2_City.ToString();
                txt_emgcnt2state.Text = obj_demo_emgr2.Emrcnt2_State.ToString();
                txt_emgcnt2zipcode.Text = obj_demo_emgr2.Emrcnt2_Zipcode.ToString();
                txt_emgcnt2homeph.Text = obj_demo_emgr2.Emrcnt2_Homeph.ToString();
                txt_emgcnt2cellph.Text = obj_demo_emgr2.Emrcnt2_Cellph.ToString();
                txt_emgcnt2workph.Text = obj_demo_emgr2.Emrcnt2_Workph.ToString();
                //obj_demo_emgr2.Emrcnt2_Relpatient = ddl_emg2rel_patient.SelectedValue.ToString();
                //obj_demo_emgr2.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //emergency contact3
                txt_emg3name.Text = obj_demo_emgr3.Emrcnt3_Name.ToString();
                txt_emg3addr1.Text = obj_demo_emgr3.Emrcnt3_Addr1.ToString();
                txt_emg3addr2.Text = obj_demo_emgr3.Emrcnt3_Addr2.ToString();
                txt_emg3city.Text = obj_demo_emgr3.Emrcnt3_City.ToString();
                txt_emg3state.Text = obj_demo_emgr3.Emrcnt3_State.ToString();
                txt_emg3zipcode.Text = obj_demo_emgr3.Emrcnt3_Zipcode.ToString();
                txt_emg3homeph.Text = obj_demo_emgr3.Emrcnt3_Homeph.ToString();
                txt_emg3cellph.Text = obj_demo_emgr3.Emrcnt3_Cellph.ToString();
                txt_emg3workph.Text = obj_demo_emgr3.Emrcnt3_Workph.ToString();
                //obj_demo_emgr3.Emrcnt3_Relpatient = ddl_emg3re_patient.SelectedValue.ToString();
                //obj_demo_emgr3.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                

            }
            catch(Exception ex)
            {
                Response.Write("Oops!Error Occure...Please Check..." + ex.Message.ToString());
            }
        }
//===============================================================================================================================

        protected void btn_Update1_Click(object sender, EventArgs e)
        {
            try
            {
                //main data
                obj_demo_main.P_Gender = ddl_Gender.SelectedValue.ToString();
                obj_demo_main.Race = chk_race.SelectedValue.ToString();
                obj_demo_main.Ethnicity = ddl_Ethnicity.SelectedValue.ToString();
                obj_demo_main.Language = ddl_lang.SelectedValue.ToString();
                obj_demo_main.HomePhone = txt_homephone.Text;
                obj_demo_main.CellPhone = txt_cellphone.Text;
                obj_demo_main.WorkPhone = txt_workphone.Text;
                obj_demo_main.EmailAddress = txt_emailaddr.Text;
                obj_demo_main.DirectAddress = txt_directaddr.Text;
                obj_demo_main.Phy_Addr1 = txt_phyaddress1.Text;
                obj_demo_main.Phy_Addr2 = txt_phyaddress2.Text;
                obj_demo_main.Phy_ACity = txt_phycity.Text;
                obj_demo_main.Phy_AState = txt_phystate.Text;
                obj_demo_main.Phy_AZipcode = txt_phyzipcode.Text;
                obj_demo_main.Insurance = lbl_insurance.Text;
                obj_demo_main.HearAboutus = ddl_aboutus.SelectedValue.ToString();
                obj_demo_main.Provider = ddl_provider.SelectedValue.ToString();
                obj_demo_main.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //billing data
                obj_demo_bill.Bill_Addr1 = txt_billaddr1.Text;
                obj_demo_bill.Bill_Addr2 = txt_billaddr2.Text;
                obj_demo_bill.Bill_City = txt_billcity.Text;
                obj_demo_bill.Bill_State = txt_billstate.Text;
                obj_demo_bill.Bill_Zipcode = txt_billzipcode.Text;
                obj_demo_bill.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //employee data
                obj_demo_emp.Emp_Name = txt_empname.Text;
                obj_demo_emp.Emp_Addr1 = txt_empaddr1.Text;
                obj_demo_emp.Emp_Addr2 = txt_empaddr2.Text;
                obj_demo_emp.Emp_City = txt_empcity.Text;
                obj_demo_emp.Emp_State = txt_empstate.Text;
                obj_demo_emp.Emp_Zipcode = txt_empzipcode.Text;
                obj_demo_emp.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //emergency contact1
                obj_demo_emgr1.Emrcnt1_Name = txt_emgcntname.Text;
                obj_demo_emgr1.Emrcnt1_Addr1 = txt_emgcntaddr1.Text;
                obj_demo_emgr1.Emrcnt1_Addr2 = txt_emgcntaddr2.Text;
                obj_demo_emgr1.Emrcnt1_City = txt_emgcntcity.Text;
                obj_demo_emgr1.Emrcnt1_State = txt_emgcntstate.Text;
                obj_demo_emgr1.Emrcnt1_Zipcode = txt_emgcntzipcode.Text;
                obj_demo_emgr1.Emrcnt1_Homeph = txt_emghomeph.Text;
                obj_demo_emgr1.Emrcnt1_Cellph = txt_emgcellph.Text;
                obj_demo_emgr1.Emrcnt1_Workph = txt_emgworkph.Text;
                obj_demo_emgr1.Emrcnt1_Relpatient = ddl_emg1rel_patient.SelectedValue.ToString();
                obj_demo_emgr1.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //emergency contact2
                obj_demo_emgr2.Emrcnt2_Name = txt_emgcnt2name.Text;
                obj_demo_emgr2.Emrcnt2_Addr1 = txt_emgcnt2addr1.Text;
                obj_demo_emgr2.Emrcnt2_Addr2 = txt_emgcnt2addr2.Text;
                obj_demo_emgr2.Emrcnt2_City = txt_emgcnt2city.Text;
                obj_demo_emgr2.Emrcnt2_State = txt_emgcnt2state.Text;
                obj_demo_emgr2.Emrcnt2_Zipcode = txt_emgcnt2zipcode.Text;
                obj_demo_emgr2.Emrcnt2_Homeph = txt_emgcnt2homeph.Text;
                obj_demo_emgr2.Emrcnt2_Cellph = txt_emgcnt2cellph.Text;
                obj_demo_emgr2.Emrcnt2_Workph = txt_emgcnt2workph.Text;
                obj_demo_emgr2.Emrcnt2_Relpatient = ddl_emg2rel_patient.SelectedValue.ToString();
                obj_demo_emgr2.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);


                //emergency contact3
                obj_demo_emgr3.Emrcnt3_Name = txt_emg3name.Text;
                obj_demo_emgr3.Emrcnt3_Addr1 = txt_emg3addr1.Text;
                obj_demo_emgr3.Emrcnt3_Addr2 = txt_emg3addr2.Text;
                obj_demo_emgr3.Emrcnt3_City = txt_emg3city.Text;
                obj_demo_emgr3.Emrcnt3_State = txt_emg3state.Text;
                obj_demo_emgr3.Emrcnt3_Zipcode = txt_emg3zipcode.Text;
                obj_demo_emgr3.Emrcnt3_Homeph = txt_emg3homeph.Text;
                obj_demo_emgr3.Emrcnt3_Cellph = txt_emg3cellph.Text;
                obj_demo_emgr3.Emrcnt3_Workph = txt_emg3workph.Text;
                obj_demo_emgr3.Emrcnt3_Relpatient = ddl_emg3re_patient.SelectedValue.ToString();
                obj_demo_emgr3.Patient_Id = Convert.ToInt32(lbl_patient_id.Text);

                //All fuction to update details to tables

                obj_Acceslayer.Get_UpdateDemoMain(obj_demo_main);
                obj_Acceslayer.Get_UpdateDemoBill(obj_demo_bill);
                obj_Acceslayer.Get_UpdateDemoEmp(obj_demo_emp);
                obj_Acceslayer.Get_UpdateDemoEmr1(obj_demo_emgr1);
                obj_Acceslayer.Get_UpdateDemoEmr2(obj_demo_emgr2);
                obj_Acceslayer.Get_UpdateDemoEmr3(obj_demo_emgr3);

                Response.Write("<Script>alert('Details are Updated Successfully...')</Script>");
                cleartextbox();
            }
            catch (Exception ex)
            {
                Response.Write("Oops!Error Occure...Please Check..." + ex.Message.ToString());
            }
        }

        private void cleartextbox()
        {
            txt_homephone.Text="";
            txt_cellphone.Text="";
            txt_workphone.Text="";
            txt_emailaddr.Text="";
            txt_directaddr.Text="";
            txt_phyaddress1.Text="";
            txt_phyaddress2.Text="";
            txt_phycity.Text="";
            txt_phystate.Text = ""; ;
            txt_phyzipcode.Text="";
            txt_billaddr1.Text = "";
            txt_billaddr2.Text = "";
            txt_billcity.Text = "";
            txt_billstate.Text = "";
            txt_billzipcode.Text = "";
            txt_empname.Text = "";
            txt_empaddr1.Text = "";
            txt_empaddr2.Text = "";
            txt_empcity.Text = "";
            txt_empstate.Text = "";
            txt_empzipcode.Text = "";
            txt_emgcntname.Text = "";
            txt_emgcntaddr1.Text = "";
            txt_emgcntaddr2.Text = "";
            txt_emgcntcity.Text = "";
            txt_emgcntstate.Text = "";
            txt_emgcntzipcode.Text = "";
            txt_emghomeph.Text = "";
            txt_emgcellph.Text = "";
            txt_emgworkph.Text = "";
            txt_emgcnt2name.Text = "";
            txt_emgcnt2addr1.Text = "";
            txt_emgcnt2addr2.Text = "";
            txt_emgcnt2city.Text = "";
            txt_emgcnt2state.Text = "";
            txt_emgcnt2zipcode.Text = "";
            txt_emgcnt2homeph.Text = "";
            txt_emgcnt2cellph.Text = "";
            txt_emgcnt2workph.Text = "";
            txt_emg3name.Text = "";
            txt_emg3addr1.Text = "";
            txt_emg3addr2.Text = "";
            txt_emg3city.Text = "";
            txt_emg3state.Text = "";
            txt_emg3zipcode.Text = "";
            txt_emg3homeph.Text = "";
            txt_emg3cellph.Text = "";
            txt_emg3workph.Text = "";
 
        }


    }
}