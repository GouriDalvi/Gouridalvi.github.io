﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Business_Entities;
using Business_LAccessLayer;

namespace HealthCare_MiniProject
{
    public partial class Login_Form : System.Web.UI.Page
    {
        Business_AccessLayer Obj_AccessLayer = new Business_AccessLayer();
        Business_Entity Obj_Entity = new Business_Entity();

        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            try
            {
                if (rd_Patient.Checked == true)
                {
                    

                    Obj_Entity.Patient_FName = txt_PatientId.Text;
                    Obj_Entity.Patient_CPwd = txt_Password.Text;

                    string log = Obj_AccessLayer.Get_Login_Dtl(Obj_Entity);
                    int i = int.Parse(log);

                    if (i > 0)
                    {
                        Session["Login"] = Obj_Entity.Patient_FName;

                        Response.Write("<Script>alert('Welcome To You User...')</Script>");

                        Response.Redirect("Demographics.aspx");

                    }
                    else
                    {
                        Response.Write("<Script>alert('Please Check UserName or Password...')</Script>");

                    }
                }
                else
                {
                    
                    Response.Write("<Script>alert('Please Login As Patient Click On Radio Button...')</Script>");

                }
                
            }
            catch (Exception ex)
            {
                Response.Write("<Script>alert('Please Check UserName or Password..')</Script>");
            }
        }


    }
}