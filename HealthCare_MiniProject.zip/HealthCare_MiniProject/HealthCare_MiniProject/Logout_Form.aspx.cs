﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HealthCare_MiniProject
{
    public partial class Logout_Form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                if (Session["Login"] == null)
                {
                    Response.Redirect("Login_Form.aspx");
                }
                else
                {
                    Session.Clear();
                    Session.Remove("Login");
                    Session["Login"] = null;


                    Response.Write("<script>window.alert('Continue To Logout...') ; window.location='Login_Form.aspx';</script>");


                    Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.Cache.SetNoStore();
                }
            }


            //Response.ClearHeaders();
            //Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
            //Response.AddHeader("Pragma", "no-cache");
        
    }
}