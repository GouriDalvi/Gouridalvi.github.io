﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Business_Entities;
using Business_LAccessLayer;

namespace HealthCare_MiniProject
{
    public partial class Register_Form : System.Web.UI.Page
    {
        Business_AccessLayer Obj_AccessLayer = new Business_AccessLayer();
        Business_Entity Obj_BusinessEntity = new Business_Entity();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Method to Clear All TextBoxes
        public void Clear_TextBox()
        {
            txt_FName.Text = String.Empty;
            txt_LName.Text = String.Empty;
            txt_DOB.Text = String.Empty;
            txt_Age.Text = String.Empty;
            txt_cpwd.Text = String.Empty;
        }

        protected void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                Obj_BusinessEntity.Patient_FName = txt_FName.Text;
                Obj_BusinessEntity.Patient_LName = txt_LName.Text;
                Obj_BusinessEntity.Patient_DOB = txt_DOB.Text;
                Obj_BusinessEntity.Patient_Age = txt_Age.Text;
                Obj_BusinessEntity.Patient_CPwd = txt_cpwd.Text;

                Obj_AccessLayer.Get_Patient(Obj_BusinessEntity);

                Response.Write("<script>alert('Details Save Successfully...')</script>");
                Clear_TextBox();
                Response.Redirect("Login_Form.aspx");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Oops! Error Occure...')</script>" + ex.Message.ToString());
                Clear_TextBox();
            }
        }

        protected void btn_Cancle_Click(object sender, EventArgs e)
        {
            Clear_TextBox();
            Response.Redirect("Login_Form.aspx");
        }


    }
}