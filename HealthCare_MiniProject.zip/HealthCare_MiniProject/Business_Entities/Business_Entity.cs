﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Entities
{
    public class Business_Entity
    {
        //Adding the All Variable of Register Patient in Database

        public int Patient_Id { get; set; }
        public string Patient_FName { get; set; }
        public string Patient_LName { get; set; }
        public string Patient_DOB { get; set; }
        public string Patient_Age { get; set;}
        public string Patient_CPwd { get; set; }
    }
// Class to Declare Variable to the Demographics
    public class Demograph
    {
        public int P_Demoghy { get; set; }
        public string P_Gender { get; set; }
        public string Race { get; set; }
        public string Ethnicity { get; set; }
        public string Language { get; set; }
        public string HomePhone { get; set; }
        public string CellPhone { get; set; }
        public string WorkPhone { get; set; }
        public string EmailAddress { get; set; }
        public string DirectAddress { get; set; }
        public string Phy_Addr1 { get; set; }
        public string Phy_Addr2 { get; set; }
        public string Phy_ACity { get; set; }
        public string Phy_AState { get; set; }
        public string Phy_AZipcode { get; set; }
        public string Insurance { get; set; }
        public string HearAboutus { get; set; }
        public string Provider { get; set; }
        public int Patient_Id { get; set; }
    }

    //Class to Declare variable to Demographic Bill
    public class Demograph_Bill
    {
        public int Bill_Id { get; set; }
        public string Bill_Addr1 { get; set; }
        public string Bill_Addr2 { get; set; }
        public string Bill_City { get; set; }
        public string Bill_State { get; set; }
        public string Bill_Zipcode { get; set; }
        public int Patient_Id { get; set; }
    }

    //Class to Declare variable to Demographic Employer
    public class Demograph_Emp
    {
        public int Emp_Id { get; set; }
        public string Emp_Name { get; set; }
        public string Emp_Addr1 { get; set; }
        public string Emp_Addr2 { get; set; }
        public string Emp_City { get; set; }
        public string Emp_State { get; set; }
        public string Emp_Zipcode { get; set; }
        public int Patient_Id { get; set; }
    }

    //Class to Declare variable to Demographic Emergency Contact1
    public class Demograph_Emg_Cnt1
    {
        public int Emrcnt1_Id { get; set; }
        public string Emrcnt1_Name { get; set; }
        public string Emrcnt1_Addr1 { get; set; }
        public string Emrcnt1_Addr2 { get; set; }
        public string Emrcnt1_City { get; set; }
        public string Emrcnt1_State { get; set; }
        public string Emrcnt1_Zipcode { get; set; }
        public string Emrcnt1_Homeph { get; set; }
        public string Emrcnt1_Cellph { get; set; }
        public string Emrcnt1_Workph { get; set; }
        public string Emrcnt1_Relpatient { get; set; }
        public int Patient_Id { get; set; }
    }

    //Class to Declare variable to Demographic Emergency Contact2
    public class Demograph_Emg_Cnt2
    {
        public int Emrcnt2_Id { get; set; }
        public string Emrcnt2_Name { get; set; }
        public string Emrcnt2_Addr1 { get; set; }
        public string Emrcnt2_Addr2 { get; set; }
        public string Emrcnt2_City { get; set; }
        public string Emrcnt2_State { get; set; }
        public string Emrcnt2_Zipcode { get; set; }
        public string Emrcnt2_Homeph { get; set; }
        public string Emrcnt2_Cellph { get; set; }
        public string Emrcnt2_Workph { get; set; }
        public string Emrcnt2_Relpatient { get; set; }
        public int Patient_Id { get; set; }
    }

    //Class to Declare variable to Demographic Emergency Contact3
    public class Demograph_Emg_Cnt3
    {
        public int Emrcnt3_Id { get; set; }
        public string Emrcnt3_Name { get; set; }
        public string Emrcnt3_Addr1 { get; set; }
        public string Emrcnt3_Addr2 { get; set; }
        public string Emrcnt3_City { get; set; }
        public string Emrcnt3_State { get; set; }
        public string Emrcnt3_Zipcode { get; set; }
        public string Emrcnt3_Homeph { get; set; }
        public string Emrcnt3_Cellph { get; set; }
        public string Emrcnt3_Workph { get; set; }
        public string Emrcnt3_Relpatient { get; set; }
        public int Patient_Id { get; set; }
    }

}//NameSpace Closing
