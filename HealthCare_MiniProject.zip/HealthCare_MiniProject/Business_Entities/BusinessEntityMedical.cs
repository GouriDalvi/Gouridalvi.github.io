﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Entities
{
    public class BusinessEntityMedical
    {
        public string Medical_History { get; set; }
        public string Other_Medical_Cond { get; set; }
        public string Parent_Marital_Status { get; set; }
        public string Allergy { get; set; }
        public string Pharmacy { get; set; }
        public string Lives_with { get; set; }
        public string Occupation { get; set; }
        public string Pets { get; set; }
        public string Smoke_Detector { get; set; }
        public string Smoking_Status { get; set; }
        public string Comment { get; set; }
        public string Start_Smoking_Date { get; set; }
        public string Quit_Smoking_Date { get; set; }
        public string Smoke_Exposure { get; set; }
        public string CO_Detector { get; set; }
        public string Firearms { get; set; }
        public string Type_Day_Care { get; set; }
        public string Day_Care_days_per_week { get; set; }
        public string Current_school_level { get; set; }
        public string Average_Grades { get; set; }
        public string Activities { get; set; }
        public string Bike_Helmet_usage { get; set; }
        public string Seat_Helmet_usage { get; set; }
        public string Car_Helmet_usage { get; set; }
        public string Average_diet { get; set; }
        public string Milk_usage { get; set; }
        public string No_of_oz_per_day { get; set; }
        public string Water_usage { get; set; }
        public string Sleeping_location { get; set; }
        public string Sleeping_frequency { get; set; }
        public int Patient_Id { get; set; }
        
    }
    //Class To Surgery Variable
    public class SurgeryMedication
    {
        public string Surgery_Year { get; set; }
        public string Surgery_Name { get; set; }
        public string Surgery_Location { get; set; }
        public int Patient_Id { get; set; }
    }

    //Class To Surgery Variable
    public class Medication1
    {
        public string Medication { get; set; }
        public string strength { get; set; }
        public string doseform { get; set; }
        public int Patient_Id { get; set; }
    }

}
