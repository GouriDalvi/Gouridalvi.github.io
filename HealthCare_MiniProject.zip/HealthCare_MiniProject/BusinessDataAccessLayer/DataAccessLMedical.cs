﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.IO;

using Business_Entities;


namespace BusinessDataAccessLayer
{
   public class DataAccessLMedical
    {

        SqlConnection Sql_Con = new SqlConnection(ConfigurationManager.ConnectionStrings["HealthCare_ConStr"].ConnectionString);

        string query;

        //Getting The Connection

        public SqlConnection GetConnection()
        {
            if (Sql_Con.State == ConnectionState.Closed)
            {
                Sql_Con.Open();
            }
            return Sql_Con;
        }

        //Closing The Connection

        public SqlConnection CloseConnection()
        {
            if (Sql_Con.State != ConnectionState.Closed)
            {
                Sql_Con.Close();
            }
            return Sql_Con;
        }

        //Insert Medical_History Details To Database
        public void Insert_Medical_History(BusinessEntityMedical Obj_EntityMedicalHistory,List<SurgeryMedication> SurgeryInsert,List<Medication1> MedictionInsert)
        {
            var conn = GetConnection();
            try
            {
                using (SqlCommand Inscmd = conn.CreateCommand())
                {
                    query = @"Insert into tbl_Medical_History values(@Medical_History,@Other_Medical_Cond,
                                                                 @Parent_Marital_Status,@Allergy,@pharmacy,@Lives_with,@Occupation,
                                                                 @Pets,@Smoke_Detector,@Smoking_Status,@Comment,
                                                                 @Start_Smoking_Date,@Quit_Smoking_Date,@Smoke_Exposure,
                                                                 @CO_Detector,@Firearms,@Type_Day_Care,@Day_Care_days_per_week,
                                                                 @Current_school_level,@Average_Grades,@Activities,@Bike_Helmet_usage,
                                                                 @Seat_Helmet_usage,@Car_Helmet_usage,@Average_diet,@Milk_usage,
                                                                 @No_of_oz_per_day,@Water_usage,@Sleeping_location,@Sleeping_frequency,@Patient_Id)";
                    Inscmd.CommandType = CommandType.Text;
                    Inscmd.CommandText = query;
                    Inscmd.Parameters.AddWithValue("@Medical_History", Obj_EntityMedicalHistory.Medical_History);
                    Inscmd.Parameters.AddWithValue("@Other_Medical_Cond", Obj_EntityMedicalHistory.Other_Medical_Cond);
                    Inscmd.Parameters.AddWithValue("@Parent_Marital_Status", Obj_EntityMedicalHistory.Parent_Marital_Status);
                    Inscmd.Parameters.AddWithValue("@Allergy", Obj_EntityMedicalHistory.Allergy);
                    Inscmd.Parameters.AddWithValue("@pharmacy", Obj_EntityMedicalHistory.Pharmacy);
                    Inscmd.Parameters.AddWithValue("@Lives_with", Obj_EntityMedicalHistory.Lives_with);
                    Inscmd.Parameters.AddWithValue("@Occupation", Obj_EntityMedicalHistory.Occupation);
                    Inscmd.Parameters.AddWithValue("@Pets", Obj_EntityMedicalHistory.Pets);
                    Inscmd.Parameters.AddWithValue("@Smoke_Detector", Obj_EntityMedicalHistory.Smoke_Detector);
                    Inscmd.Parameters.AddWithValue("@Smoking_Status", Obj_EntityMedicalHistory.Smoking_Status);
                    Inscmd.Parameters.AddWithValue("@Comment", Obj_EntityMedicalHistory.Comment);
                    Inscmd.Parameters.AddWithValue("@Start_Smoking_Date", Obj_EntityMedicalHistory.Start_Smoking_Date);
                    Inscmd.Parameters.AddWithValue("@Quit_Smoking_Date", Obj_EntityMedicalHistory.Quit_Smoking_Date);
                    Inscmd.Parameters.AddWithValue("@Smoke_Exposure", Obj_EntityMedicalHistory.Smoke_Exposure);
                    Inscmd.Parameters.AddWithValue("@CO_Detector", Obj_EntityMedicalHistory.CO_Detector);
                    Inscmd.Parameters.AddWithValue("@Firearms", Obj_EntityMedicalHistory.Firearms);
                    Inscmd.Parameters.AddWithValue("@Type_Day_Care", Obj_EntityMedicalHistory.Type_Day_Care);
                    Inscmd.Parameters.AddWithValue("@Day_Care_days_per_week", Obj_EntityMedicalHistory.Day_Care_days_per_week);
                    Inscmd.Parameters.AddWithValue("@Current_school_level", Obj_EntityMedicalHistory.Current_school_level);
                    Inscmd.Parameters.AddWithValue("@Average_Grades", Obj_EntityMedicalHistory.Average_Grades);
                    Inscmd.Parameters.AddWithValue("@Activities", Obj_EntityMedicalHistory.Activities);
                    Inscmd.Parameters.AddWithValue("@Bike_Helmet_usage", Obj_EntityMedicalHistory.Bike_Helmet_usage);
                    Inscmd.Parameters.AddWithValue("@Seat_Helmet_usage", Obj_EntityMedicalHistory.Seat_Helmet_usage);
                    Inscmd.Parameters.AddWithValue("@Car_Helmet_usage", Obj_EntityMedicalHistory.Car_Helmet_usage);
                    Inscmd.Parameters.AddWithValue("@Average_diet", Obj_EntityMedicalHistory.Average_diet);
                    Inscmd.Parameters.AddWithValue("@Milk_usage", Obj_EntityMedicalHistory.Milk_usage);
                    Inscmd.Parameters.AddWithValue("@No_of_oz_per_day", Obj_EntityMedicalHistory.No_of_oz_per_day);
                    Inscmd.Parameters.AddWithValue("@Water_usage", Obj_EntityMedicalHistory.Water_usage);
                    Inscmd.Parameters.AddWithValue("@Sleeping_location", Obj_EntityMedicalHistory.Sleeping_location);
                    Inscmd.Parameters.AddWithValue("@Sleeping_frequency", Obj_EntityMedicalHistory.Sleeping_frequency);
                    Inscmd.Parameters.AddWithValue("@Patient_Id", Obj_EntityMedicalHistory.Patient_Id);

                    Inscmd.Connection = GetConnection();
                    Inscmd.ExecuteNonQuery();

                }
                foreach (var item in SurgeryInsert)
                {
                    SqlCommand sqlCmd = conn.CreateCommand();
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = @"Insert into tbl_SurgeryMedication values(@Surgery_Year,@Surgery_Name,@Surgery_Location,@Medication,
                                                                                 @strength,@doesform,@Patient_Id)";
                    sqlCmd.Parameters.AddWithValue("@Surgery_Year", item.Surgery_Year);
                    sqlCmd.Parameters.AddWithValue("@Surgery_Name", item.Surgery_Name);
                    sqlCmd.Parameters.AddWithValue("@Surgery_Location", item.Surgery_Location);
                    
                    sqlCmd.Parameters.AddWithValue("@Patient_Id", item.Patient_Id);
                    sqlCmd.Connection = GetConnection();
                    sqlCmd.ExecuteNonQuery();

                }
                foreach (var item1 in MedictionInsert)
                {
                    SqlCommand sqlCmd = conn.CreateCommand();
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = @"Insert into tbl_Medication values(@Medication,@strength,@doesform,@Patient_Id)";
                    
                    sqlCmd.Parameters.AddWithValue("@Medication", item1.Medication);
                    sqlCmd.Parameters.AddWithValue("@strength", item1.strength);
                    sqlCmd.Parameters.AddWithValue("@doesform", item1.doseform);
                    sqlCmd.Parameters.AddWithValue("@Patient_Id", item1.Patient_Id);
                    sqlCmd.Connection = GetConnection();
                    sqlCmd.ExecuteNonQuery();

                }

                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
 
        }


//===============================================================================================================================================
//Update Demographic Details Function
//============================================================================================================================================================
        public void Update_Medical_History(BusinessEntityMedical Obj_EntityMedicalHistory1)
        {
            //BusinessEntityMedical Obj_EntityMedicalHistory = new BusinessEntityMedical();
            try
            {
                query = @"UPDATE tbl_Medical_History SET Medical_History=@Medical_History,Other_Medical_Cond=@Other_Medical_Cond,
                                                                 Parent_Marital_Status=@Parent_Marital_Status,Allergy=@Allergy,Pharmacy=@pharmacy,Lives_with=@Lives_with,Occupation=@Occupation,
                                                                 Pets=@Pets,Smoke_Detector=@Smoke_Detector,Smoking_Status=@Smoking_Status,Comment=@Comment,
                                                                 Start_Smoking_Date=@Start_Smoking_Date,Quit_Smoking_Date=@Quit_Smoking_Date,Smoke_Exposure=@Smoke_Exposure,
                                                                 CO_Detector=@CO_Detector,Firearms=@Firearms,Type_Day_Care=@Type_Day_Care,Day_Care_days_per_week=@Day_Care_days_per_week,
                                                                 Current_school_level=@Current_school_level,Average_Grades=@Average_Grades,Activities=@Activities,Bike_Helmet_usage=@Bike_Helmet_usage,
                                                                 Seat_Helmet_usage=@Seat_Helmet_usage,Car_Helemet_usage=@Car_Helmet_usage,Average_diet=@Average_diet,Milk_usage=@Milk_usage,
                                                                 No_of_oz_per_day=@No_of_oz_per_day,Water_usage=@Water_usage,Sleeping_location=@Sleeping_location,Sleeping_frequency=@Sleeping_frequency where Patient_Id=@Patient_Id";
                SqlCommand Inscmd = new SqlCommand(query, Sql_Con);
                
                Inscmd.Parameters.AddWithValue("@Medical_History", Obj_EntityMedicalHistory1.Medical_History);
                Inscmd.Parameters.AddWithValue("@Other_Medical_Cond", Obj_EntityMedicalHistory1.Other_Medical_Cond);
                Inscmd.Parameters.AddWithValue("@Parent_Marital_Status", Obj_EntityMedicalHistory1.Parent_Marital_Status);
                Inscmd.Parameters.AddWithValue("@Allergy", Obj_EntityMedicalHistory1.Allergy);
                Inscmd.Parameters.AddWithValue("@pharmacy", Obj_EntityMedicalHistory1.Pharmacy);
                Inscmd.Parameters.AddWithValue("@Lives_with", Obj_EntityMedicalHistory1.Lives_with);
                Inscmd.Parameters.AddWithValue("@Occupation", Obj_EntityMedicalHistory1.Occupation);
                Inscmd.Parameters.AddWithValue("@Pets", Obj_EntityMedicalHistory1.Pets);
                Inscmd.Parameters.AddWithValue("@Smoke_Detector", Obj_EntityMedicalHistory1.Smoke_Detector);
                Inscmd.Parameters.AddWithValue("@Smoking_Status", Obj_EntityMedicalHistory1.Smoking_Status);
                Inscmd.Parameters.AddWithValue("@Comment", Obj_EntityMedicalHistory1.Comment);
                Inscmd.Parameters.AddWithValue("@Start_Smoking_Date", Obj_EntityMedicalHistory1.Start_Smoking_Date);
                Inscmd.Parameters.AddWithValue("@Quit_Smoking_Date", Obj_EntityMedicalHistory1.Quit_Smoking_Date);
                Inscmd.Parameters.AddWithValue("@Smoke_Exposure", Obj_EntityMedicalHistory1.Smoke_Exposure);
                Inscmd.Parameters.AddWithValue("@CO_Detector", Obj_EntityMedicalHistory1.CO_Detector);
                Inscmd.Parameters.AddWithValue("@Firearms", Obj_EntityMedicalHistory1.Firearms);
                Inscmd.Parameters.AddWithValue("@Type_Day_Care", Obj_EntityMedicalHistory1.Type_Day_Care);
                Inscmd.Parameters.AddWithValue("@Day_Care_days_per_week", Obj_EntityMedicalHistory1.Day_Care_days_per_week);
                Inscmd.Parameters.AddWithValue("@Current_school_level", Obj_EntityMedicalHistory1.Current_school_level);
                Inscmd.Parameters.AddWithValue("@Average_Grades", Obj_EntityMedicalHistory1.Average_Grades);
                Inscmd.Parameters.AddWithValue("@Activities", Obj_EntityMedicalHistory1.Activities);
                Inscmd.Parameters.AddWithValue("@Bike_Helmet_usage", Obj_EntityMedicalHistory1.Bike_Helmet_usage);
                Inscmd.Parameters.AddWithValue("@Seat_Helmet_usage", Obj_EntityMedicalHistory1.Seat_Helmet_usage);
                Inscmd.Parameters.AddWithValue("@Car_Helmet_usage", Obj_EntityMedicalHistory1.Car_Helmet_usage);
                Inscmd.Parameters.AddWithValue("@Average_diet", Obj_EntityMedicalHistory1.Average_diet);
                Inscmd.Parameters.AddWithValue("@Milk_usage", Obj_EntityMedicalHistory1.Milk_usage);
                Inscmd.Parameters.AddWithValue("@No_of_oz_per_day", Obj_EntityMedicalHistory1.No_of_oz_per_day);
                Inscmd.Parameters.AddWithValue("@Water_usage", Obj_EntityMedicalHistory1.Water_usage);
                Inscmd.Parameters.AddWithValue("@Sleeping_location", Obj_EntityMedicalHistory1.Sleeping_location);
                Inscmd.Parameters.AddWithValue("@Sleeping_frequency", Obj_EntityMedicalHistory1.Sleeping_frequency);
                Inscmd.Parameters.AddWithValue("@Patient_Id", Obj_EntityMedicalHistory1.Patient_Id);

                GetConnection();
                Inscmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }



    }//Class Closing
}//NameSpoace Closing
