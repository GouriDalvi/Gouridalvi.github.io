﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.IO;


using Business_Entities;

namespace BusinessDataAccessLayer
{
    public class DataAccessLayer
    {
        SqlConnection Sql_Con =new SqlConnection(ConfigurationManager.ConnectionStrings["HealthCare_ConStr"].ConnectionString);

        string query;

        //Getting The Connection

        public SqlConnection GetConnection()
        {
            if (Sql_Con.State == ConnectionState.Closed)
            {
                Sql_Con.Open();
            }
            return Sql_Con;
        }

        //Closing The Connection

        public SqlConnection CloseConnection()
        {
            if (Sql_Con.State != ConnectionState.Closed)
            {
                Sql_Con.Close();
            }
            return Sql_Con;
        }

        //Insert patient Details To Database

        public Int32 Insert_PatientDtl(Business_Entity obj_BusinessEntity)
        {
            try
            {
                query = "Insert Into tbl_Patient values(@Patient_FName,@Patient_LName,@Patient_DOB,@Patient_Age,@Patient_CPwd)";

                SqlCommand cmd = new SqlCommand(query, Sql_Con);

                //Adding Paramter To Table
                cmd.Parameters.AddWithValue("@Patient_FName", obj_BusinessEntity.Patient_FName);
                cmd.Parameters.AddWithValue("@Patient_LName", obj_BusinessEntity.Patient_LName);
                cmd.Parameters.AddWithValue("@Patient_DOB", obj_BusinessEntity.Patient_DOB);
                cmd.Parameters.AddWithValue("@Patient_Age", obj_BusinessEntity.Patient_Age);
                cmd.Parameters.AddWithValue("@Patient_CPwd", obj_BusinessEntity.Patient_CPwd);

                GetConnection();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    return result;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Select Login Details 

        public string Login_Dtl(Business_Entity Obj_BEL)
        {
            string login_dtl;
            try
            {
                query = "Select * from tbl_Patient where Patient_Fname='" + Obj_BEL.Patient_FName + "' and Patient_CPwd='" + Obj_BEL.Patient_CPwd + "'";

                SqlCommand cmd = new SqlCommand(query, Sql_Con);

                GetConnection();
                login_dtl = cmd.ExecuteScalar().ToString();
                return login_dtl;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function to Bind data to label patient id

        public Business_Entity Bind_Paitent_id(string name)
        {
            Business_Entity obj_entity = new Business_Entity();
            try
            {
                query = "Select * from tbl_Patient where Patient_FName='" + name + "'";

                SqlCommand bind_cmd = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_reader = bind_cmd.ExecuteReader();

                while (obj_reader.Read())
                {
                    obj_entity.Patient_Id = obj_reader.GetInt32(obj_reader.GetOrdinal("Patient_Id"));
                }
                return obj_entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Insert the Details To Demographics Main Table

        public int Insert_Demo_Main(Demograph Obj_Demo_Main)
        {
            try
            {
                query = @"Insert into tbl_Demogrphy_Main values(@P_Gender,@Race,@Ethnicity,@Language,@HomePhone,
                                                                @CellPhone,@WorkPhone,@EmailAddress,@DirectAddress,
                                                                @Phy_Addr1,@Phy_Addr2,@Phy_ACity,@Phy_AState,
                                                                @Phy_AZipcode,@Insurance,@HearAboutus,@Provider,@Patient_Id)";
                SqlCommand Main_cmd = new SqlCommand(query, Sql_Con);

                Main_cmd.Parameters.AddWithValue("@P_Gender", Obj_Demo_Main.P_Gender);
                Main_cmd.Parameters.AddWithValue("@Race", Obj_Demo_Main.Race);
                Main_cmd.Parameters.AddWithValue("@Ethnicity", Obj_Demo_Main.Ethnicity);
                Main_cmd.Parameters.AddWithValue("@Language", Obj_Demo_Main.Language);
                Main_cmd.Parameters.AddWithValue("@HomePhone", Obj_Demo_Main.HomePhone);
                Main_cmd.Parameters.AddWithValue("@CellPhone", Obj_Demo_Main.CellPhone);
                Main_cmd.Parameters.AddWithValue("@WorkPhone", Obj_Demo_Main.WorkPhone);
                Main_cmd.Parameters.AddWithValue("@EmailAddress", Obj_Demo_Main.EmailAddress);
                Main_cmd.Parameters.AddWithValue("@DirectAddress", Obj_Demo_Main.DirectAddress);
                Main_cmd.Parameters.AddWithValue("@Phy_Addr1", Obj_Demo_Main.Phy_Addr1);
                Main_cmd.Parameters.AddWithValue("@Phy_Addr2", Obj_Demo_Main.Phy_Addr2);
                Main_cmd.Parameters.AddWithValue("@Phy_ACity", Obj_Demo_Main.Phy_ACity);
                Main_cmd.Parameters.AddWithValue("@Phy_AState", Obj_Demo_Main.Phy_AState);
                Main_cmd.Parameters.AddWithValue("@Phy_AZipcode", Obj_Demo_Main.Phy_AZipcode);
                Main_cmd.Parameters.AddWithValue("@Insurance", Obj_Demo_Main.Insurance);
                Main_cmd.Parameters.AddWithValue("@HearAboutus", Obj_Demo_Main.HearAboutus);
                Main_cmd.Parameters.AddWithValue("@Provider", Obj_Demo_Main.Provider);
                Main_cmd.Parameters.AddWithValue("@Patient_Id", Obj_Demo_Main.Patient_Id);

                GetConnection();
                int result = Main_cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    return result;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Insert the Details To Demographics Bill Table

        public int Insert_Demo_Bill(Demograph_Bill Obj_Demo_Bill)
        {
            try
            {
                query = @"Insert into tbl_Demo_Bill values(@Bill_Addr1,@Bill_Addr2,@Bill_City,@Bill_State,
                                                                @Bill_Zipcode,@Patient_Id)";
                SqlCommand Bill_cmd = new SqlCommand(query, Sql_Con);

                Bill_cmd.Parameters.AddWithValue("@Bill_Addr1", Obj_Demo_Bill.Bill_Addr1);
                Bill_cmd.Parameters.AddWithValue("@Bill_Addr2", Obj_Demo_Bill.Bill_Addr2);
                Bill_cmd.Parameters.AddWithValue("@Bill_City", Obj_Demo_Bill.Bill_City);
                Bill_cmd.Parameters.AddWithValue("@Bill_State", Obj_Demo_Bill.Bill_State);
                Bill_cmd.Parameters.AddWithValue("@Bill_Zipcode", Obj_Demo_Bill.Bill_Zipcode);
                Bill_cmd.Parameters.AddWithValue("@Patient_Id", Obj_Demo_Bill.Patient_Id);

                GetConnection();
                int result_bill = Bill_cmd.ExecuteNonQuery();

                if (result_bill > 0)
                {
                    return result_bill;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Insert the Details To Demographics Employer Table

        public int Insert_Demo_Emp(Demograph_Emp Obj_Demo_Emp)
        {
            try
            {
                query = @"Insert into tbl_Demo_Emp values(@Emp_Name,@Emp_Addr1,@Emp_Addr2,@Emp_City,@Emp_State,
                                                                @Emp_Zipcode,@Patient_Id)";
                SqlCommand Emp_cmd = new SqlCommand(query, Sql_Con);

                Emp_cmd.Parameters.AddWithValue("@Emp_Name", Obj_Demo_Emp.Emp_Name);
                Emp_cmd.Parameters.AddWithValue("@Emp_Addr1", Obj_Demo_Emp.Emp_Addr1);
                Emp_cmd.Parameters.AddWithValue("@Emp_Addr2", Obj_Demo_Emp.Emp_Addr2);
                Emp_cmd.Parameters.AddWithValue("@Emp_City", Obj_Demo_Emp.Emp_City);
                Emp_cmd.Parameters.AddWithValue("@Emp_State", Obj_Demo_Emp.Emp_State);
                Emp_cmd.Parameters.AddWithValue("@Emp_Zipcode", Obj_Demo_Emp.Emp_Zipcode);
                Emp_cmd.Parameters.AddWithValue("@Patient_Id", Obj_Demo_Emp.Patient_Id);

                GetConnection();
                int result_emp = Emp_cmd.ExecuteNonQuery();

                if (result_emp > 0)
                {
                    return result_emp;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Insert the Details To Demographics Emergency Contact1 Table

        public int Insert_Demo_Emercnt1(Demograph_Emg_Cnt1 Obj_Demo_emrg1)
        {
            try
            {
                query = @"Insert into tbl_Demo_EmergyCnt1 values(@Emrcnt1_Name,@Emrcnt1_Addr1,@Emrcnt1_Addr2,
                                                                @Emrcnt1_City,@Emrcnt1_State,@Emrcnt1_Zipcode,
                                                                @Emrcnt1_Homeph,@Emrcnt1_Cellph,@Emrcnt1_Workph,
                                                                @Emrcnt1_Relpatient,@Patient_Id)";
                SqlCommand emrg1_cmd = new SqlCommand(query, Sql_Con);

                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Name", Obj_Demo_emrg1.Emrcnt1_Name);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Addr1", Obj_Demo_emrg1.Emrcnt1_Addr1);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Addr2", Obj_Demo_emrg1.Emrcnt1_Addr2);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_City", Obj_Demo_emrg1.Emrcnt1_City);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_State", Obj_Demo_emrg1.Emrcnt1_State);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Zipcode", Obj_Demo_emrg1.Emrcnt1_Zipcode);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Homeph", Obj_Demo_emrg1.Emrcnt1_Homeph);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Cellph", Obj_Demo_emrg1.Emrcnt1_Cellph);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Workph", Obj_Demo_emrg1.Emrcnt1_Workph);
                emrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Relpatient", Obj_Demo_emrg1.Emrcnt1_Relpatient);
                emrg1_cmd.Parameters.AddWithValue("@Patient_Id", Obj_Demo_emrg1.Patient_Id);

                GetConnection();
                int result_emr1 = emrg1_cmd.ExecuteNonQuery();

                if (result_emr1 > 0)
                {
                    return result_emr1;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Insert the Details To Demographics Emergency Contact2 Table

        public int Insert_Demo_Emercnt2(Demograph_Emg_Cnt2 Obj_Demo_emrg2)
        {
            try
            {
                query = @"Insert into tbl_Demo_EmrgyCnt2 values(@Emrcnt2_Name,@Emrcnt2_Addr1,@Emrcnt2_Addr2,
                                                                @Emrcnt2_City,@Emrcnt2_State,@Emrcnt2_Zipcode,
                                                                @Emrcnt2_Homeph,@Emrcnt2_Cellph,@Emrcnt2_Workph,
                                                                @Emrcnt2_Relpatient,@Patient_Id)";
                SqlCommand emrg2_cmd = new SqlCommand(query, Sql_Con);

                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Name", Obj_Demo_emrg2.Emrcnt2_Name);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Addr1", Obj_Demo_emrg2.Emrcnt2_Addr1);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Addr2", Obj_Demo_emrg2.Emrcnt2_Addr2);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_City", Obj_Demo_emrg2.Emrcnt2_City);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_State", Obj_Demo_emrg2.Emrcnt2_State);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Zipcode", Obj_Demo_emrg2.Emrcnt2_Zipcode);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Homeph", Obj_Demo_emrg2.Emrcnt2_Homeph);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Cellph", Obj_Demo_emrg2.Emrcnt2_Cellph);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Workph", Obj_Demo_emrg2.Emrcnt2_Workph);
                emrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Relpatient", Obj_Demo_emrg2.Emrcnt2_Relpatient);
                emrg2_cmd.Parameters.AddWithValue("@Patient_Id", Obj_Demo_emrg2.Patient_Id);

                GetConnection();
                int result_emr2 = emrg2_cmd.ExecuteNonQuery();

                if (result_emr2 > 0)
                {
                    return result_emr2;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function To Insert the Details To Demographics Emergency Contact3 Table

        public int Insert_Demo_Emercnt3(Demograph_Emg_Cnt3 Obj_Demo_emrg3)
        {
            try
            {
                query = @"Insert into tbl_Demo_EmergyCnt3 values(@Emrcnt3_Name,@Emrcnt3_Addr1,@Emrcnt3_Addr2,
                                                                @Emrcnt3_City,@Emrcnt3_State,@Emrcnt3_Zipcode,
                                                                @Emrcnt3_Homeph,@Emrcnt3_Cellph,@Emrcnt3_Workph,
                                                                @Emrcnt3_Relpatient,@Patient_Id)";
                SqlCommand emrg3_cmd = new SqlCommand(query, Sql_Con);

                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Name", Obj_Demo_emrg3.Emrcnt3_Name);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Addr1", Obj_Demo_emrg3.Emrcnt3_Addr1);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Addr2", Obj_Demo_emrg3.Emrcnt3_Addr2);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_City", Obj_Demo_emrg3.Emrcnt3_City);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_State", Obj_Demo_emrg3.Emrcnt3_State);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Zipcode", Obj_Demo_emrg3.Emrcnt3_Zipcode);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Homeph", Obj_Demo_emrg3.Emrcnt3_Homeph);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Cellph", Obj_Demo_emrg3.Emrcnt3_Cellph);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Workph", Obj_Demo_emrg3.Emrcnt3_Workph);
                emrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Relpatient", Obj_Demo_emrg3.Emrcnt3_Relpatient);
                emrg3_cmd.Parameters.AddWithValue("@Patient_Id", Obj_Demo_emrg3.Patient_Id);

                GetConnection();
                int result_emr3 = emrg3_cmd.ExecuteNonQuery();

                if (result_emr3 > 0)
                {
                    return result_emr3;
                }
                else
                {
                    return 0;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }
//===============================================================================================================================================
        //Update Demographic Details Function
//===============================================================================================================================================
        //Function to Select the Details to update the Demographics Main Details
        public Demograph SUpdate_DemoMainDetail(int name)
        {
            Demograph obj_Demogrphy=new Demograph();

            try
            {
                query = @"SELECT DM.HomePhone,DM.CellPhone,DM.WorkPhone,DM.EmailAddress,
                            DM.DirectAddress,DM.Phy_Addr1,DM.Phy_Addr2,DM.Phy_ACity,DM.Phy_AState,
                            DM.Phy_AZipcode,DM.Insurance,DM.Patient_Id
                            FROM tbl_Demogrphy_Main DM 
                            WHERE DM.Patient_Id='" + name+"'";
                            
                SqlCommand SUp_demodtl = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_datareader;
                obj_datareader = SUp_demodtl.ExecuteReader();

                while (obj_datareader.Read())
                {
                    //selecting demoghraphic main details
                    obj_Demogrphy.HomePhone = obj_datareader.GetString(obj_datareader.GetOrdinal("HomePhone"));
                    obj_Demogrphy.CellPhone = obj_datareader.GetString(obj_datareader.GetOrdinal("CellPhone"));
                    obj_Demogrphy.WorkPhone = obj_datareader.GetString(obj_datareader.GetOrdinal("WorkPhone"));
                    obj_Demogrphy.EmailAddress = obj_datareader.GetString(obj_datareader.GetOrdinal("EmailAddress"));
                    obj_Demogrphy.DirectAddress = obj_datareader.GetString(obj_datareader.GetOrdinal("DirectAddress"));
                    obj_Demogrphy.Phy_Addr1 = obj_datareader.GetString(obj_datareader.GetOrdinal("Phy_Addr1"));
                    obj_Demogrphy.Phy_Addr2 = obj_datareader.GetString(obj_datareader.GetOrdinal("Phy_Addr2"));
                    obj_Demogrphy.Phy_ACity = obj_datareader.GetString(obj_datareader.GetOrdinal("Phy_ACity"));
                    obj_Demogrphy.Phy_AState = obj_datareader.GetString(obj_datareader.GetOrdinal("Phy_AState"));
                    obj_Demogrphy.Phy_AZipcode = obj_datareader.GetString(obj_datareader.GetOrdinal("Phy_AZipcode"));
                    obj_Demogrphy.Insurance = obj_datareader.GetString(obj_datareader.GetOrdinal("Insurance"));
                    //obj_Demogrphy.HearAboutus = obj_datareader.GetString(obj_datareader.GetOrdinal("HearAboutus"));
                    //obj_Demogrphy.Provider = obj_datareader.GetString(obj_datareader.GetOrdinal("Provider"));

               
                }
                return obj_Demogrphy;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function to Select the Details to update the Demographics Bill Details
        public Demograph_Bill SUpdate_DemoBillDetail(int name)
        {
            Demograph_Bill obj_dbill = new Demograph_Bill();

            try
            {
                query = @"SELECT DB.Bill_Addr1,DB.Bill_Addr2,DB.Bill_City,
                            DB.Bill_State,DB.Bill_Zipcode,DB.Patient_Id
                            FROM tbl_Demo_Bill DB 
                            WHERE DB.Patient_Id='" + name + "'";

                SqlCommand SUp_demobdtl = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_datareader;
                obj_datareader = SUp_demobdtl.ExecuteReader();

                while (obj_datareader.Read())
                {
                    //selecting billing details
                    obj_dbill.Bill_Addr1 = obj_datareader.GetString(obj_datareader.GetOrdinal("Bill_Addr1"));
                    obj_dbill.Bill_Addr2 = obj_datareader.GetString(obj_datareader.GetOrdinal("Bill_Addr2"));
                    obj_dbill.Bill_City = obj_datareader.GetString(obj_datareader.GetOrdinal("Bill_City"));
                    obj_dbill.Bill_State = obj_datareader.GetString(obj_datareader.GetOrdinal("Bill_State"));
                    obj_dbill.Bill_Zipcode = obj_datareader.GetString(obj_datareader.GetOrdinal("Bill_Zipcode"));

                }
                return obj_dbill;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function to Select the Details to update the Demographics Employee Details
        public Demograph_Emp SUpdate_DemoEmpDetail(int name)
        {
            Demograph_Emp obj_demp = new Demograph_Emp();

            try
            {
                query = @"SELECT DE.Emp_Name,DE.Emp_Addr1,DE.Emp_Addr2,DE.Emp_City,
                            DE.Emp_State,DE.Emp_Zipcode,DE.Patient_Id
                            FROM tbl_Demo_Emp DE 
                            WHERE DE.Patient_Id='" + name + "'";

                SqlCommand SUp_demoedtl = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_datareader;
                obj_datareader = SUp_demoedtl.ExecuteReader();

                while (obj_datareader.Read())
                {
                   

                    //selecting employee details
                    obj_demp.Emp_Name = obj_datareader.GetString(obj_datareader.GetOrdinal("Emp_Name"));
                    obj_demp.Emp_Addr1 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emp_Addr1"));
                    obj_demp.Emp_Addr2 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emp_Addr2"));
                    obj_demp.Emp_City = obj_datareader.GetString(obj_datareader.GetOrdinal("Emp_City"));
                    obj_demp.Emp_State = obj_datareader.GetString(obj_datareader.GetOrdinal("Emp_State"));
                    obj_demp.Emp_Zipcode = obj_datareader.GetString(obj_datareader.GetOrdinal("Emp_Zipcode"));

                }
                return obj_demp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function to Select the Details to update the Demographics Emergency Details
        public Demograph_Emg_Cnt1 SUpdate_DemoEmr1Detail(int name)
        {
            Demograph_Emg_Cnt1 obj_demgcnt1 = new Demograph_Emg_Cnt1();

            try
            {
                query = @"SELECT DEC1.Emrcnt1_Name,DEC1.Emrcnt1_Addr1,DEC1.Emrcnt1_Addr2,
                            DEC1.Emrcnt1_City,DEC1.Emrcnt1_State,DEC1.Emrcnt1_Zipcode,DEC1.Emrcnt1_Homeph,
                            DEC1.Emrcnt1_Cellph,DEC1.Emrcnt1_Workph,DEC1.Patient_Id
                            FROM  tbl_Demo_EmergyCnt1 DEC1
                            WHERE DEC1.Patient_Id='" + name + "'";

                SqlCommand SUp_demodtl = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_datareader;
                obj_datareader = SUp_demodtl.ExecuteReader();

                while (obj_datareader.Read())
                {
                   
                    //selecting emergency contact#1
                    obj_demgcnt1.Emrcnt1_Name = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Name"));
                    obj_demgcnt1.Emrcnt1_Addr1 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Addr1"));
                    obj_demgcnt1.Emrcnt1_Addr2 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Addr2"));
                    obj_demgcnt1.Emrcnt1_City = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_City"));
                    obj_demgcnt1.Emrcnt1_State = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_State"));
                    obj_demgcnt1.Emrcnt1_Zipcode = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Zipcode"));
                    obj_demgcnt1.Emrcnt1_Homeph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Homeph"));
                    obj_demgcnt1.Emrcnt1_Cellph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Cellph"));
                    obj_demgcnt1.Emrcnt1_Workph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt1_Workph"));

                }
                return obj_demgcnt1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function to Select the Details to update the Demographics Emergency Details
        public Demograph_Emg_Cnt2 SUpdate_DemoEmr2Detail(int name)
        {
            Demograph_Emg_Cnt2 obj_demgcnt2 = new Demograph_Emg_Cnt2();

            try
            {
                query = @"SELECT DEC2.Emrcnt2_Name,DEC2.Emrcnt2_Addr1,DEC2.Emrcnt2_Addr2,
                            DEC2.Emrcnt2_City,DEC2.Emrcnt2_State,DEC2.Emrcnt2_Zipcode,DEC2.Emrcnt2_Homeph,
                            DEC2.Emrcnt2_Cellph,DEC2.Emrcnt2_Workph,DEC2.Patient_Id
                            FROM  tbl_Demo_EmrgyCnt2 DEC2
                            WHERE DEC2.Patient_Id='" + name + "'";

                SqlCommand SUp_demodtl = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_datareader;
                obj_datareader = SUp_demodtl.ExecuteReader();

                while (obj_datareader.Read())
                {

                    //selecting emergency contact#2
                    obj_demgcnt2.Emrcnt2_Name = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Name"));
                    obj_demgcnt2.Emrcnt2_Addr1 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Addr1"));
                    obj_demgcnt2.Emrcnt2_Addr2 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Addr2"));
                    obj_demgcnt2.Emrcnt2_City = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_City"));
                    obj_demgcnt2.Emrcnt2_State = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_State"));
                    obj_demgcnt2.Emrcnt2_Zipcode = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Zipcode"));
                    obj_demgcnt2.Emrcnt2_Homeph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Homeph"));
                    obj_demgcnt2.Emrcnt2_Cellph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Cellph"));
                    obj_demgcnt2.Emrcnt2_Workph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt2_Workph"));

                }
                return obj_demgcnt2;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //Function to Select the Details to update the Demographics Main Details
        public Demograph_Emg_Cnt3 SUpdate_DemoEmr3Detail(int name)
        {
            Demograph_Emg_Cnt3 obj_demgcnt3 = new Demograph_Emg_Cnt3();

            try
            {
                query = @"SELECT DEC3.Emrcnt3_Name,DEC3.Emrcnt3_Addr1,DEC3.Emrcnt3_Addr2,
                            DEC3.Emrcnt3_City,DEC3.Emrcnt3_State,DEC3.Emrcnt3_Zipcode,DEC3.Emrcnt3_Homeph,
                            DEC3.Emrcnt3_Cellph,DEC3.Emrcnt3_Workph,DEC3.Patient_Id
                            FROM tbl_Demo_EmergyCnt3 DEC3 
                            WHERE DEC3.Patient_Id='" + name + "'";

                SqlCommand SUp_demodtl = new SqlCommand(query, Sql_Con);

                GetConnection();
                SqlDataReader obj_datareader;
                obj_datareader = SUp_demodtl.ExecuteReader();

                while (obj_datareader.Read())
                {
                    //selecting emergency contact#3
                    obj_demgcnt3.Emrcnt3_Name = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Name"));
                    obj_demgcnt3.Emrcnt3_Addr1 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Addr1"));
                    obj_demgcnt3.Emrcnt3_Addr2 = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Addr2"));
                    obj_demgcnt3.Emrcnt3_City = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_City"));
                    obj_demgcnt3.Emrcnt3_State = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_State"));
                    obj_demgcnt3.Emrcnt3_Zipcode = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Zipcode"));
                    obj_demgcnt3.Emrcnt3_Homeph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Homeph"));
                    obj_demgcnt3.Emrcnt3_Cellph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Cellph"));
                    obj_demgcnt3.Emrcnt3_Workph = obj_datareader.GetString(obj_datareader.GetOrdinal("Emrcnt3_Workph"));

                }
                return obj_demgcnt3;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

//====================================================================================================================================
        //FUNCTIONS TO UPDATE THE ALL THE DETAILS
//=====================================================================================================================================
        //FUNCTION TO UPDATE THE DEMOGRAPHIC MAIN DETAILS
        public void Update_DemoMain(Demograph obj_demomain)
        {
            try
            {
                query = @"UPDATE tbl_Demogrphy_Main SET  P_Gender=@P_Gender,Race=@Race,Ethnicity=@Ethnicity,
                                                                Language=@Language,HomePhone=@HomePhone,
                                                                CellPhone=@CellPhone,WorkPhone=@WorkPhone,
                                                                EmailAddress=@EmailAddress,DirectAddress=@DirectAddress,
                                                                Phy_Addr1=@Phy_Addr1,Phy_Addr2=@Phy_Addr2,
                                                                Phy_ACity=@Phy_ACity,Phy_AState=@Phy_AState,
                                                                Phy_AZipcode=@Phy_AZipcode,Insurance=@Insurance,
                                                                HearAboutus=@HearAboutus,Provider=@Provider
                                                                WHERE Patient_Id=@Patient_Id";
                SqlCommand UpMain_cmd = new SqlCommand(query, Sql_Con);

                UpMain_cmd.Parameters.AddWithValue("@P_Gender", obj_demomain.P_Gender);
                UpMain_cmd.Parameters.AddWithValue("@Race", obj_demomain.Race);
                UpMain_cmd.Parameters.AddWithValue("@Ethnicity", obj_demomain.Ethnicity);
                UpMain_cmd.Parameters.AddWithValue("@Language", obj_demomain.Language);
                UpMain_cmd.Parameters.AddWithValue("@HomePhone", obj_demomain.HomePhone);
                UpMain_cmd.Parameters.AddWithValue("@CellPhone", obj_demomain.CellPhone);
                UpMain_cmd.Parameters.AddWithValue("@WorkPhone", obj_demomain.WorkPhone);
                UpMain_cmd.Parameters.AddWithValue("@EmailAddress", obj_demomain.EmailAddress);
                UpMain_cmd.Parameters.AddWithValue("@DirectAddress", obj_demomain.DirectAddress);
                UpMain_cmd.Parameters.AddWithValue("@Phy_Addr1", obj_demomain.Phy_Addr1);
                UpMain_cmd.Parameters.AddWithValue("@Phy_Addr2", obj_demomain.Phy_Addr2);
                UpMain_cmd.Parameters.AddWithValue("@Phy_ACity", obj_demomain.Phy_ACity);
                UpMain_cmd.Parameters.AddWithValue("@Phy_AState", obj_demomain.Phy_AState);
                UpMain_cmd.Parameters.AddWithValue("@Phy_AZipcode", obj_demomain.Phy_AZipcode);
                UpMain_cmd.Parameters.AddWithValue("@Insurance", obj_demomain.Insurance);
                UpMain_cmd.Parameters.AddWithValue("@HearAboutus", obj_demomain.HearAboutus);
                UpMain_cmd.Parameters.AddWithValue("@Provider", obj_demomain.Provider);
                UpMain_cmd.Parameters.AddWithValue("@Patient_Id", obj_demomain.Patient_Id);

                GetConnection();
                UpMain_cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //FUNCTION TO UPDATE THE DEMOGRAPHIC BILL DETAILS
        public void Update_DemoBill(Demograph_Bill obj_demobill)
        {
            try
            {
                query = @"UPDATE tbl_Demo_Bill SET Bill_Addr1=@Bill_Addr1,Bill_Addr2=@Bill_Addr2,
                                                              Bill_City=@Bill_City,Bill_State=@Bill_State,
                                                              Bill_Zipcode=@Bill_Zipcode
                                                              WHERE Patient_Id=@Patient_Id";
                SqlCommand UpBill_cmd = new SqlCommand(query, Sql_Con);

                UpBill_cmd.Parameters.AddWithValue("@Bill_Addr1", obj_demobill.Bill_Addr1);
                UpBill_cmd.Parameters.AddWithValue("@Bill_Addr2", obj_demobill.Bill_Addr2);
                UpBill_cmd.Parameters.AddWithValue("@Bill_City", obj_demobill.Bill_City);
                UpBill_cmd.Parameters.AddWithValue("@Bill_State", obj_demobill.Bill_State);
                UpBill_cmd.Parameters.AddWithValue("@Bill_Zipcode", obj_demobill.Bill_Zipcode);
                UpBill_cmd.Parameters.AddWithValue("@Patient_Id", obj_demobill.Patient_Id);

                GetConnection();
                UpBill_cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //FUNCTION TO UPDATE THE DEMOGRAPHIC EMPLOYEE DETAILS
        public void Update_DemoEmp(Demograph_Emp obj_demoemp)
        {
            try
            {
                query = @"UPDATE tbl_Demo_Emp SET Emp_Name=@Emp_Name,Emp_Addr1=@Emp_Addr1,
                                                  Emp_Addr2=@Emp_Addr2,Emp_City=@Emp_City,
                                                  Emp_State=@Emp_State,Emp_Zipcode=@Emp_Zipcode
                                                  WHERE Patient_Id=@Patient_Id";
                SqlCommand UpEmp_cmd = new SqlCommand(query, Sql_Con);

                UpEmp_cmd.Parameters.AddWithValue("@Emp_Name", obj_demoemp.Emp_Name);
                UpEmp_cmd.Parameters.AddWithValue("@Emp_Addr1", obj_demoemp.Emp_Addr1);
                UpEmp_cmd.Parameters.AddWithValue("@Emp_Addr2", obj_demoemp.Emp_Addr2);
                UpEmp_cmd.Parameters.AddWithValue("@Emp_City", obj_demoemp.Emp_City);
                UpEmp_cmd.Parameters.AddWithValue("@Emp_State", obj_demoemp.Emp_State);
                UpEmp_cmd.Parameters.AddWithValue("@Emp_Zipcode", obj_demoemp.Emp_Zipcode);
                UpEmp_cmd.Parameters.AddWithValue("@Patient_Id", obj_demoemp.Patient_Id);

                GetConnection();
                UpEmp_cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //FUNCTION TO UPDATE THE DEMOGRAPHIC EMERGENCY CONTACT1 DETAILS
        public void Update_DemoEmr1(Demograph_Emg_Cnt1 obj_emr1)
        {
            try
            {
                query = @"UPDATE tbl_Demo_EmergyCnt1 SET Emrcnt1_Name=@Emrcnt1_Name,Emrcnt1_Addr1=@Emrcnt1_Addr1,
                                                                Emrcnt1_Addr2=@Emrcnt1_Addr2,Emrcnt1_City=@Emrcnt1_City,
                                                                Emrcnt1_State=@Emrcnt1_State,Emrcnt1_Zipcode=@Emrcnt1_Zipcode,
                                                                Emrcnt1_Homeph=@Emrcnt1_Homeph,Emrcnt1_Cellph=@Emrcnt1_Cellph,
                                                                Emrcnt1_Workph=@Emrcnt1_Workph,Emrcnt1_Relpatient=@Emrcnt1_Relpatient
                                                                WHERE Patient_Id=@Patient_Id";
                SqlCommand Upemrg1_cmd = new SqlCommand(query, Sql_Con);

                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Name", obj_emr1.Emrcnt1_Name);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Addr1", obj_emr1.Emrcnt1_Addr1);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Addr2", obj_emr1.Emrcnt1_Addr2);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_City", obj_emr1.Emrcnt1_City);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_State", obj_emr1.Emrcnt1_State);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Zipcode", obj_emr1.Emrcnt1_Zipcode);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Homeph", obj_emr1.Emrcnt1_Homeph);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Cellph", obj_emr1.Emrcnt1_Cellph);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Workph", obj_emr1.Emrcnt1_Workph);
                Upemrg1_cmd.Parameters.AddWithValue("@Emrcnt1_Relpatient", obj_emr1.Emrcnt1_Relpatient);
                Upemrg1_cmd.Parameters.AddWithValue("@Patient_Id", obj_emr1.Patient_Id);

                GetConnection();
                Upemrg1_cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        //FUNCTION TO UPDATE THE DEMOGRAPHIC EMERGENCY CONTACT2 DETAILS
        public void Update_DemoEmr2(Demograph_Emg_Cnt2 obj_emr2)
        {
            try
            {
                query = @"UPDATE tbl_Demo_EmrgyCnt2 SET Emrcnt2_Name=@Emrcnt2_Name,Emrcnt2_Addr1=@Emrcnt2_Addr1,
                                                                Emrcnt2_Addr2=@Emrcnt2_Addr2,
                                                                Emrcnt2_City=@Emrcnt2_City,Emrcnt2_State=@Emrcnt2_State,
                                                                Emrcnt2_Zipcode=@Emrcnt2_Zipcode,
                                                                Emrcnt2_Homeph=@Emrcnt2_Homeph,Emrcnt2_Cellph=@Emrcnt2_Cellph,
                                                                Emrcnt2_Workph=@Emrcnt2_Workph,
                                                                Emrcnt2_Relpatient=@Emrcnt2_Relpatient
                                                                WHERE Patient_Id=@Patient_Id";
                SqlCommand Upemrg2_cmd = new SqlCommand(query, Sql_Con);

                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Name", obj_emr2.Emrcnt2_Name);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Addr1", obj_emr2.Emrcnt2_Addr1);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Addr2", obj_emr2.Emrcnt2_Addr2);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_City", obj_emr2.Emrcnt2_City);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_State", obj_emr2.Emrcnt2_State);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Zipcode", obj_emr2.Emrcnt2_Zipcode);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Homeph", obj_emr2.Emrcnt2_Homeph);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Cellph", obj_emr2.Emrcnt2_Cellph);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Workph", obj_emr2.Emrcnt2_Workph);
                Upemrg2_cmd.Parameters.AddWithValue("@Emrcnt2_Relpatient", obj_emr2.Emrcnt2_Relpatient);
                Upemrg2_cmd.Parameters.AddWithValue("@Patient_Id", obj_emr2.Patient_Id);

                GetConnection();
                Upemrg2_cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }

        }

        //FUNCTION TO UPDATE THE DEMOGRAPHIC EMERGENCY CONTACT3 DETAILS
        public void Update_DemoEmr3(Demograph_Emg_Cnt3 obj_emr3)
        {
            try
            {
                query = @"UPDATE tbl_Demo_EmergyCnt3 SET Emrcnt3_Name=@Emrcnt3_Name,Emrcnt3_Addr1=@Emrcnt3_Addr1,Emrcnt3_Addr2=@Emrcnt3_Addr2,
                                                                Emrcnt3_City=@Emrcnt3_City,Emrcnt3_State=@Emrcnt3_State,Emrcnt3_Zipcode=@Emrcnt3_Zipcode,
                                                                Emrcnt3_Homeph=@Emrcnt3_Homeph,Emrcnt3_Cellph=@Emrcnt3_Cellph,Emrcnt3_Workph=@Emrcnt3_Workph,
                                                                Emrcnt3_Relpatient=@Emrcnt3_Relpatient WHERE Patient_Id=@Patient_Id";
                SqlCommand Upemrg3_cmd = new SqlCommand(query, Sql_Con);

                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Name", obj_emr3.Emrcnt3_Name);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Addr1", obj_emr3.Emrcnt3_Addr1);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Addr2", obj_emr3.Emrcnt3_Addr2);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_City", obj_emr3.Emrcnt3_City);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_State", obj_emr3.Emrcnt3_State);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Zipcode", obj_emr3.Emrcnt3_Zipcode);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Homeph", obj_emr3.Emrcnt3_Homeph);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Cellph", obj_emr3.Emrcnt3_Cellph);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Workph", obj_emr3.Emrcnt3_Workph);
                Upemrg3_cmd.Parameters.AddWithValue("@Emrcnt3_Relpatient", obj_emr3.Emrcnt3_Relpatient);
                Upemrg3_cmd.Parameters.AddWithValue("@Patient_Id", obj_emr3.Patient_Id);

                GetConnection();
                Upemrg3_cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }


    }//Class Closing
}//NameSpace Closing
