﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Business_Entities;
using BusinessDataAccessLayer;

namespace Business_LAccessLayer
{
    public class Business_AccessLMedical
    {
        DataAccessLMedical obj_DAL = new DataAccessLMedical();

        //===============================================================================================
        //FUNCTION TO INSERT MEDICAL + SURGERY DETAILS...
        public void Get_Medical_History_Dtl(BusinessEntityMedical ObjBEM, List<SurgeryMedication> SurgeryMedication, List<Medication1> Medication)
        {
            obj_DAL.Insert_Medical_History(ObjBEM, SurgeryMedication,Medication);
        }
        //================================================================================================
        //Update Details Function
        //============================================================================================================
        //Function to selecting details to textboxes
        //=============================================================================================================
        public void Get_SUpdate_Medical_History( BusinessEntityMedical obj_medical)
        {
            try
            {
                obj_DAL.Update_Medical_History(obj_medical);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
