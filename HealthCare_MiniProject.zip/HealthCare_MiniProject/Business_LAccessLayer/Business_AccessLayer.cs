﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Business_Entities;
using BusinessDataAccessLayer;

namespace Business_LAccessLayer
{
    public class Business_AccessLayer
    {
        DataAccessLayer Obj_DataAccess = new DataAccessLayer();
        
        //Function To Save The Patient Details 
        public Int32 Get_Patient(Business_Entity Obj_BusinessEntity)
        {
            try
            {
                return Obj_DataAccess.Insert_PatientDtl(Obj_BusinessEntity);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function To Do Login

        public string Get_Login_Dtl(Business_Entity Obj_BE)
        {
            try
            {
                return Obj_DataAccess.Login_Dtl(Obj_BE);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to bind the data to lable 

        public Business_Entity Get_bind_patient(string lblname)
        {
            try
            {
                return Obj_DataAccess.Bind_Paitent_id(lblname);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function To Save Demography Main Details

        public Int32 Get_Demo_Main(Demograph obj_Demo_main_dtl)
        {
            try
            {
                return Obj_DataAccess.Insert_Demo_Main(obj_Demo_main_dtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function To Save Demography Bill Details

        public Int32 Get_Demo_Bill(Demograph_Bill obj_Demo_bill_dtl)
        {
            try
            {
                return Obj_DataAccess.Insert_Demo_Bill(obj_Demo_bill_dtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function To Save Demography Employee Details

        public Int32 Get_Demo_Emp(Demograph_Emp obj_Demo_emp_dtl)
        {
            try
            {
                return Obj_DataAccess.Insert_Demo_Emp(obj_Demo_emp_dtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function To Save Demography Emergency Contact1 Details

        public Int32 Get_Demo_Emerg1(Demograph_Emg_Cnt1 obj_Demo_emg_dtl)
        {
            try
            {
                return Obj_DataAccess.Insert_Demo_Emercnt1(obj_Demo_emg_dtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function To Save Demography Emergency Contact2 Details

        public Int32 Get_Demo_Emerg2(Demograph_Emg_Cnt2 obj_Demo_emg2_dtl)
        {
            try
            {
                return Obj_DataAccess.Insert_Demo_Emercnt2(obj_Demo_emg2_dtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //Function To Save Demography Emergency Contact3 Details

        public Int32 Get_Demo_Emerg3(Demograph_Emg_Cnt3 obj_Demo_emg3_dtl)
        {
            try
            {
                return Obj_DataAccess.Insert_Demo_Emercnt3(obj_Demo_emg3_dtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
//============================================================================================================
        //Update Details Function
//============================================================================================================
        //Function to selecting details to textboxes
        public Demograph Get_SUpdate_Details(int name1)
        {
            try
            {
                return Obj_DataAccess.SUpdate_DemoMainDetail(name1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to selecting bill details to textboxes
        public Demograph_Bill Get_SUpdateBill_Details(int name1)
        {
            try
            {
                return Obj_DataAccess.SUpdate_DemoBillDetail(name1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to selecting employee details to textboxes
        public Demograph_Emp Get_SUpdateEmp_Details(int name1)
        {
            try
            {
                return Obj_DataAccess.SUpdate_DemoEmpDetail(name1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to selecting emergency contact1 details to textboxes
        public Demograph_Emg_Cnt1 Get_SUpdateEmr1_Details(int name1)
        {
            try
            {
                return Obj_DataAccess.SUpdate_DemoEmr1Detail(name1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to selecting emergency contact2 details to textboxes
        public Demograph_Emg_Cnt2 Get_SUpdateEmr2_Details(int name1)
        {
            try
            {
                return Obj_DataAccess.SUpdate_DemoEmr2Detail(name1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to selecting emergency contact3 details to textboxes
        public Demograph_Emg_Cnt3 Get_SUpdateEmr3_Details(int name1)
        {
            try
            {
                return Obj_DataAccess.SUpdate_DemoEmr3Detail(name1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

//======================================================================================================================
        //FUNCTION TO UPDATE ALL DETAILS
//======================================================================================================================
        //FUNCTION TO GET UPDATED THE DEMOGRAPHIC DETAILS
        public void Get_UpdateDemoMain(Demograph obj_dmain)
        {
            try
            {
                Obj_DataAccess.Update_DemoMain(obj_dmain);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //FUNCTION TO GET UPDATED THE DEMOGRAPHIC BILL DETAILS
        public void Get_UpdateDemoBill(Demograph_Bill obj_dbill)
        {
            try
            {
                Obj_DataAccess.Update_DemoBill(obj_dbill);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //FUNCTION TO GET UPDATED THE EMPLOYEE DETAILS
        public void Get_UpdateDemoEmp(Demograph_Emp obj_demp)
        {
            try
            {
                Obj_DataAccess.Update_DemoEmp(obj_demp);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //FUNCTION TO GET UPDATED THE EMERGENCY CONTACT1 DETAILS
        public void Get_UpdateDemoEmr1(Demograph_Emg_Cnt1 obj_demr1)
        {
            try
            {
                Obj_DataAccess.Update_DemoEmr1(obj_demr1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCTION TO GET UPDATED THE EMERGENCY CONTACT2 DETAILS
        public void Get_UpdateDemoEmr2(Demograph_Emg_Cnt2 obj_demr2)
        {
            try
            {
                Obj_DataAccess.Update_DemoEmr2(obj_demr2);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //FUNCTION TO GET UPDATED THE EMERGENCY CONTACT3 DETAILS
        public void Get_UpdateDemoEmr3(Demograph_Emg_Cnt3 obj_demr3)
        {
            try
            {
                Obj_DataAccess.Update_DemoEmr3(obj_demr3);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }//Class Closing
}//NameSpace Closing
